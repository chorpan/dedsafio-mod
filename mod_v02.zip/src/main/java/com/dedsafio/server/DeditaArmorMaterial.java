package com.dedsafio.server;

import net.minecraft.sounds.SoundEvent;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.ArmorMaterial;
import net.minecraft.world.item.ArmorMaterials;
import net.minecraft.world.item.crafting.Ingredient;

public class DeditaArmorMaterial implements ArmorMaterial {
    public static final DeditaArmorMaterial INSTANCE = new DeditaArmorMaterial();

    @Override
    public int getDurabilityForType(ArmorItem.Type type) {
        return switch (type) {
            case HELMET -> 385;
            case CHESTPLATE -> 560;
            case LEGGINGS -> 525;
            case BOOTS -> 455;
        };
    }

    @Override
    public int getDefenseForType(ArmorItem.Type type) {
        return switch (type) {
            case HELMET -> 3;
            case CHESTPLATE -> 8;
            case LEGGINGS -> 6;
            case BOOTS -> 3;
        };
    }

    @Override public int getEnchantmentValue() { return 20; }
    @Override public SoundEvent getEquipSound() { return ArmorMaterials.DIAMOND.getEquipSound(); }
    @Override public Ingredient getRepairIngredient() { return Ingredient.of(ModItems.DEDITA_AZUL.get()); }
    @Override public String getName() { return DedsafioServer.MODID + ":dedita"; }
    @Override public float getToughness() { return 2.0F; }
    @Override public float getKnockbackResistance() { return 0.05F; }
}
