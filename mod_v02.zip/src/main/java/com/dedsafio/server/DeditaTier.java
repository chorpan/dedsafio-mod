package com.dedsafio.server;

import net.minecraft.world.item.Tier;
import net.minecraft.world.item.crafting.Ingredient;

public class DeditaTier implements Tier {
    public static final DeditaTier INSTANCE = new DeditaTier();
    @Override public int getUses() { return 1500; }
    @Override public float getSpeed() { return 8.0F; }
    @Override public float getAttackDamageBonus() { return 3.0F; }
    @Override public int getLevel() { return 3; }
    @Override public int getEnchantmentValue() { return 20; }
    @Override public Ingredient getRepairIngredient() { return Ingredient.of(ModItems.DEDITA_AZUL.get()); }
}
