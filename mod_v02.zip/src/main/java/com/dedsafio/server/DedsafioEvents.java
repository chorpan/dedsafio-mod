package com.dedsafio.server;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.GameType;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = DedsafioServer.MODID)
public class DedsafioEvents {

    @SubscribeEvent
    public static void alMorir(LivingDeathEvent e) {
        if (!(e.getEntity() instanceof ServerPlayer p) || !Config.ELIMINACION.get()) return;
        EliminadosData.get(p.server).add(p.getUUID());
        Anuncios.chat(p.server, Component.literal("\u2620 " + p.getGameProfile().getName() + " fue eliminado del Dedsafio")
                .withStyle(ChatFormatting.RED));
    }

    @SubscribeEvent
    public static void alRespawnear(PlayerEvent.PlayerRespawnEvent e) {
        if (e.getEntity() instanceof ServerPlayer p) aplicarEliminacion(p);
    }

    @SubscribeEvent
    public static void alEntrar(PlayerEvent.PlayerLoggedInEvent e) {
        if (!(e.getEntity() instanceof ServerPlayer p)) return;
        aplicarEliminacion(p);
        int cartas = EconomiaData.get(p.server).cartas(p.getUUID());
        if (cartas > 0) {
            p.sendSystemMessage(Component.literal("Tenes " + cartas + " carta(s). Usa /correo leer").withStyle(ChatFormatting.YELLOW));
        }
    }

    private static void aplicarEliminacion(ServerPlayer p) {
        if (Config.ELIMINACION.get() && EliminadosData.get(p.server).contains(p.getUUID())) {
            p.setGameMode(GameType.SPECTATOR);
        }
    }
}
