package com.dedsafio.server;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.levelgen.Heightmap;

/** Usalo sobre un jugador para mandarlo a su punto de respawn (o al spawn del mundo). */
public class PalitoMagicoItem extends Item {
    public PalitoMagicoItem(Properties props) { super(props); }

    @Override
    public InteractionResult interactLivingEntity(ItemStack stack, Player user, LivingEntity target, InteractionHand hand) {
        if (user.level().isClientSide() || !(target instanceof ServerPlayer sp)) return InteractionResult.PASS;
        ServerLevel dest = sp.server.getLevel(sp.getRespawnDimension());
        BlockPos pos = sp.getRespawnPosition();
        if (dest == null || pos == null) {
            dest = sp.server.overworld();
            pos = dest.getHeightmapPos(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, dest.getSharedSpawnPos());
        } else {
            pos = pos.above();
        }
        sp.teleportTo(dest, pos.getX() + 0.5, pos.getY(), pos.getZ() + 0.5, sp.getYRot(), sp.getXRot());
        user.getCooldowns().addCooldown(this, 200);
        return InteractionResult.SUCCESS;
    }
}
