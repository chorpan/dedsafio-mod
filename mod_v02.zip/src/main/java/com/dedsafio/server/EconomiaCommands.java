package com.dedsafio.server;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import java.util.List;
import net.minecraft.ChatFormatting;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** /saldo, /cajero y /correo (para todos los jugadores). */
@Mod.EventBusSubscriber(modid = DedsafioServer.MODID)
public class EconomiaCommands {

    @SubscribeEvent
    public static void registrar(RegisterCommandsEvent e) {
        CommandDispatcher<CommandSourceStack> d = e.getDispatcher();
        d.register(Commands.literal("saldo").executes(EconomiaCommands::saldo));
        d.register(Commands.literal("cajero")
                .then(Commands.literal("depositar").executes(EconomiaCommands::depositar))
                .then(Commands.literal("retirar")
                        .then(Commands.argument("cantidad", IntegerArgumentType.integer(1, 2304)).executes(EconomiaCommands::retirar)))
                .then(Commands.literal("pagar")
                        .then(Commands.argument("jugador", EntityArgument.player())
                                .then(Commands.argument("cantidad", IntegerArgumentType.integer(1)).executes(EconomiaCommands::pagar)))));
        d.register(Commands.literal("correo")
                .then(Commands.literal("enviar")
                        .then(Commands.argument("jugador", EntityArgument.player())
                                .then(Commands.argument("texto", StringArgumentType.greedyString()).executes(EconomiaCommands::enviar))))
                .then(Commands.literal("leer").executes(EconomiaCommands::leer)));
    }

    private static int valor(Item i) {
        if (i == ModItems.DEDITA_AZUL.get()) return 1;
        if (i == ModItems.DEDITA_ROJA.get()) return 5;
        if (i == ModItems.DEDITA_VERDE.get()) return 10;
        return 0;
    }

    private static int saldo(CommandContext<CommandSourceStack> c) throws CommandSyntaxException {
        ServerPlayer p = c.getSource().getPlayerOrException();
        int s = EconomiaData.get(p.server).saldo(p.getUUID());
        c.getSource().sendSuccess(() -> Component.literal("Saldo: " + s + " deditas (azul=1, roja=5, verde=10)").withStyle(ChatFormatting.AQUA), false);
        return s;
    }

    private static int depositar(CommandContext<CommandSourceStack> c) throws CommandSyntaxException {
        ServerPlayer p = c.getSource().getPlayerOrException();
        ItemStack mano = p.getMainHandItem();
        int v = valor(mano.getItem());
        if (v == 0) { c.getSource().sendFailure(Component.literal("Tenes que tener deditas en la mano")); return 0; }
        int total = v * mano.getCount();
        mano.shrink(mano.getCount());
        EconomiaData.get(p.server).sumar(p.getUUID(), total);
        c.getSource().sendSuccess(() -> Component.literal("Depositaste " + total + " deditas").withStyle(ChatFormatting.GREEN), false);
        return total;
    }

    private static int retirar(CommandContext<CommandSourceStack> c) throws CommandSyntaxException {
        ServerPlayer p = c.getSource().getPlayerOrException();
        int n = IntegerArgumentType.getInteger(c, "cantidad");
        if (!EconomiaData.get(p.server).restar(p.getUUID(), n)) {
            c.getSource().sendFailure(Component.literal("No te alcanza el saldo"));
            return 0;
        }
        int resto = n;
        while (resto > 0) {
            int cant = Math.min(64, resto);
            ItemStack st = new ItemStack(ModItems.DEDITA_AZUL.get(), cant);
            if (!p.getInventory().add(st)) p.drop(st, false);
            resto -= cant;
        }
        c.getSource().sendSuccess(() -> Component.literal("Retiraste " + n + " deditas azules").withStyle(ChatFormatting.GREEN), false);
        return n;
    }

    private static int pagar(CommandContext<CommandSourceStack> c) throws CommandSyntaxException {
        ServerPlayer p = c.getSource().getPlayerOrException();
        ServerPlayer otro = EntityArgument.getPlayer(c, "jugador");
        int n = IntegerArgumentType.getInteger(c, "cantidad");
        if (otro.getUUID().equals(p.getUUID())) { c.getSource().sendFailure(Component.literal("No podes pagarte a vos mismo")); return 0; }
        EconomiaData d = EconomiaData.get(p.server);
        if (!d.restar(p.getUUID(), n)) { c.getSource().sendFailure(Component.literal("No te alcanza el saldo")); return 0; }
        d.sumar(otro.getUUID(), n);
        otro.sendSystemMessage(Component.literal(p.getGameProfile().getName() + " te pago " + n + " deditas").withStyle(ChatFormatting.GREEN));
        c.getSource().sendSuccess(() -> Component.literal("Le pagaste " + n + " deditas a " + otro.getGameProfile().getName()), false);
        return n;
    }

    private static int enviar(CommandContext<CommandSourceStack> c) throws CommandSyntaxException {
        ServerPlayer p = c.getSource().getPlayerOrException();
        ServerPlayer otro = EntityArgument.getPlayer(c, "jugador");
        String texto = StringArgumentType.getString(c, "texto");
        EconomiaData.get(p.server).enviar(otro.getUUID(), p.getGameProfile().getName() + ": " + texto);
        otro.sendSystemMessage(Component.literal("Te llego una carta de " + p.getGameProfile().getName() + ". Usa /correo leer").withStyle(ChatFormatting.YELLOW));
        c.getSource().sendSuccess(() -> Component.literal("Carta enviada"), false);
        return 1;
    }

    private static int leer(CommandContext<CommandSourceStack> c) throws CommandSyntaxException {
        ServerPlayer p = c.getSource().getPlayerOrException();
        List<String> cartas = EconomiaData.get(p.server).vaciar(p.getUUID());
        if (cartas.isEmpty()) { c.getSource().sendSuccess(() -> Component.literal("No tenes cartas"), false); return 0; }
        for (String m : cartas) p.sendSystemMessage(Component.literal("[Carta] " + m).withStyle(ChatFormatting.WHITE));
        return cartas.size();
    }
}
