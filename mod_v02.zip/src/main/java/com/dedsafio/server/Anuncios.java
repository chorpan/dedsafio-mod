package com.dedsafio.server;

import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.game.ClientboundSetSubtitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetTitleTextPacket;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;

public final class Anuncios {
    private Anuncios() {}

    public static void chat(MinecraftServer server, Component msg) {
        server.getPlayerList().broadcastSystemMessage(msg, false);
    }

    public static void titulo(MinecraftServer server, Component titulo, Component subtitulo) {
        for (ServerPlayer p : server.getPlayerList().getPlayers()) {
            p.connection.send(new ClientboundSetSubtitleTextPacket(subtitulo));
            p.connection.send(new ClientboundSetTitleTextPacket(titulo));
        }
    }
}
