package com.dedsafio.server;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.StringTag;
import net.minecraft.nbt.Tag;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.level.saveddata.SavedData;

/** Lista persistente (guardada en el mundo) de jugadores eliminados. */
public class EliminadosData extends SavedData {
    private final Set<UUID> eliminados = new HashSet<>();

    public static EliminadosData get(MinecraftServer server) {
        return server.overworld().getDataStorage().computeIfAbsent(EliminadosData::load, EliminadosData::new, "dedsafio_eliminados");
    }

    public static EliminadosData load(CompoundTag tag) {
        EliminadosData d = new EliminadosData();
        ListTag list = tag.getList("uuids", Tag.TAG_STRING);
        for (int i = 0; i < list.size(); i++) d.eliminados.add(UUID.fromString(list.getString(i)));
        return d;
    }

    @Override
    public CompoundTag save(CompoundTag tag) {
        ListTag list = new ListTag();
        for (UUID u : eliminados) list.add(StringTag.valueOf(u.toString()));
        tag.put("uuids", list);
        return tag;
    }

    public boolean add(UUID u) { boolean r = eliminados.add(u); setDirty(); return r; }
    public boolean remove(UUID u) { boolean r = eliminados.remove(u); setDirty(); return r; }
    public boolean contains(UUID u) { return eliminados.contains(u); }
    public Set<UUID> all() { return Set.copyOf(eliminados); }
}
