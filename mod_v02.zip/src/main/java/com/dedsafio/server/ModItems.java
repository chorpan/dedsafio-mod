package com.dedsafio.server;

import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.AxeItem;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.PickaxeItem;
import net.minecraft.world.item.SwordItem;
import net.minecraftforge.common.ForgeSpawnEggItem;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModItems {
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, DedsafioServer.MODID);
    public static final DeferredRegister<CreativeModeTab> TABS = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, DedsafioServer.MODID);

    public static final RegistryObject<Item> DEDITA_AZUL = ITEMS.register("dedita_azul", () -> new Item(new Item.Properties()));
    public static final RegistryObject<Item> DEDITA_ROJA = ITEMS.register("dedita_roja", () -> new Item(new Item.Properties()));
    public static final RegistryObject<Item> DEDITA_VERDE = ITEMS.register("dedita_verde", () -> new Item(new Item.Properties()));
    public static final RegistryObject<Item> PALITO_MAGICO = ITEMS.register("palito_magico", () -> new PalitoMagicoItem(new Item.Properties().stacksTo(1)));

    public static final RegistryObject<Item> ESPADA_DEDITA = ITEMS.register("espada_dedita", () -> new SwordItem(DeditaTier.INSTANCE, 3, -2.4F, new Item.Properties()));
    public static final RegistryObject<Item> PICO_DEDITA = ITEMS.register("pico_dedita", () -> new PickaxeItem(DeditaTier.INSTANCE, 1, -2.8F, new Item.Properties()));
    public static final RegistryObject<Item> HACHA_DEDITA = ITEMS.register("hacha_dedita", () -> new AxeItem(DeditaTier.INSTANCE, 5.0F, -3.0F, new Item.Properties()));
    public static final RegistryObject<Item> CASCO_DEDITA = ITEMS.register("casco_dedita", () -> new ArmorItem(DeditaArmorMaterial.INSTANCE, ArmorItem.Type.HELMET, new Item.Properties()));
    public static final RegistryObject<Item> PETO_DEDITA = ITEMS.register("peto_dedita", () -> new ArmorItem(DeditaArmorMaterial.INSTANCE, ArmorItem.Type.CHESTPLATE, new Item.Properties()));
    public static final RegistryObject<Item> PANTALONES_DEDITA = ITEMS.register("pantalones_dedita", () -> new ArmorItem(DeditaArmorMaterial.INSTANCE, ArmorItem.Type.LEGGINGS, new Item.Properties()));
    public static final RegistryObject<Item> BOTAS_DEDITA = ITEMS.register("botas_dedita", () -> new ArmorItem(DeditaArmorMaterial.INSTANCE, ArmorItem.Type.BOOTS, new Item.Properties()));

    public static final RegistryObject<Item> GUARDIAN_HUEVO = ITEMS.register("guardian_desafio_spawn_egg",
            () -> new ForgeSpawnEggItem(ModEntities.GUARDIAN, 0x1B2A6B, 0xE6B800, new Item.Properties()));

    public static final RegistryObject<CreativeModeTab> TAB = TABS.register("dedsafio", () -> CreativeModeTab.builder()
            .title(Component.translatable("itemGroup.dedsafio_server"))
            .icon(() -> DEDITA_AZUL.get().getDefaultInstance())
            .displayItems((params, out) -> ITEMS.getEntries().forEach(i -> out.accept(i.get())))
            .build());
}
