package com.dedsafio.server;

import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITIES = DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, DedsafioServer.MODID);

    public static final RegistryObject<EntityType<GuardianDesafio>> GUARDIAN = ENTITIES.register("guardian_desafio",
            () -> EntityType.Builder.of(GuardianDesafio::new, MobCategory.MONSTER)
                    .sized(0.9F, 2.9F).clientTrackingRange(10).fireImmune()
                    .build("guardian_desafio"));
}
