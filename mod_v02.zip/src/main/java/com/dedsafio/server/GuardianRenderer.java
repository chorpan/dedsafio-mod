package com.dedsafio.server;

import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.ZombieRenderer;
import net.minecraft.world.entity.monster.Zombie;

public class GuardianRenderer extends ZombieRenderer {
    public GuardianRenderer(EntityRendererProvider.Context ctx) { super(ctx); }

    @Override
    protected void scale(Zombie zombie, PoseStack poseStack, float partialTick) {
        poseStack.scale(1.45F, 1.45F, 1.45F);
    }
}
