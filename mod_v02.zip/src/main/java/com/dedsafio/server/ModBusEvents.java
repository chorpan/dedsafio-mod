package com.dedsafio.server;

import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = DedsafioServer.MODID, bus = Mod.EventBusSubscriber.Bus.MOD)
public class ModBusEvents {
    @SubscribeEvent
    public static void atributos(EntityAttributeCreationEvent event) {
        event.put(ModEntities.GUARDIAN.get(), GuardianDesafio.atributos().build());
    }
}
