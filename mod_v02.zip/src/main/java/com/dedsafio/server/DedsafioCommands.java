package com.dedsafio.server;

import com.mojang.authlib.GameProfile;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import java.util.Set;
import java.util.UUID;
import net.minecraft.ChatFormatting;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.SharedSuggestionProvider;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.players.GameProfileCache;
import net.minecraft.world.Difficulty;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.GameType;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = DedsafioServer.MODID)
public class DedsafioCommands {
    private static final String[] MODOS = {"survival", "creative", "adventure", "spectator"};
    private static final String[] NIVELES = {"pacifico", "facil", "normal", "dificil"};
    private static final String[] DESTINOS = {"limbo", "islas", "overworld"};

    @SubscribeEvent
    public static void registrar(RegisterCommandsEvent e) {
        CommandDispatcher<CommandSourceStack> d = e.getDispatcher();
        d.register(Commands.literal("dedsafio").requires(s -> s.hasPermission(2))
                .then(Commands.literal("revive")
                        .then(Commands.argument("jugador", EntityArgument.player())
                                .executes(c -> revivir(c, GameType.SURVIVAL))
                                .then(Commands.argument("modo", StringArgumentType.word())
                                        .suggests((c, b) -> SharedSuggestionProvider.suggest(MODOS, b))
                                        .executes(c -> {
                                            GameType m = GameType.byName(StringArgumentType.getString(c, "modo"), null);
                                            if (m == null) { c.getSource().sendFailure(Component.literal("Modo invalido")); return 0; }
                                            return revivir(c, m);
                                        }))))
                .then(Commands.literal("eliminar")
                        .then(Commands.argument("jugador", EntityArgument.player()).executes(DedsafioCommands::eliminar)))
                .then(Commands.literal("eliminados").executes(DedsafioCommands::listar))
                .then(Commands.literal("dificultad")
                        .then(Commands.argument("nivel", StringArgumentType.word())
                                .suggests((c, b) -> SharedSuggestionProvider.suggest(NIVELES, b))
                                .executes(DedsafioCommands::dificultad)))
                .then(Commands.literal("ruleta").executes(DedsafioCommands::ruleta))
                .then(Commands.literal("anuncio")
                        .then(Commands.argument("texto", StringArgumentType.greedyString()).executes(c -> {
                            Anuncios.titulo(c.getSource().getServer(), Component.literal("DEDSAFIO").withStyle(ChatFormatting.GOLD),
                                    Component.literal(StringArgumentType.getString(c, "texto")));
                            return 1;
                        })))
                .then(Commands.literal("arena").executes(DedsafioCommands::arena))
                .then(Commands.literal("ir")
                        .then(Commands.argument("destino", StringArgumentType.word())
                                .suggests((c, b) -> SharedSuggestionProvider.suggest(DESTINOS, b))
                                .executes(DedsafioCommands::ir))));
    }

    private static int revivir(CommandContext<CommandSourceStack> c, GameType modo) throws CommandSyntaxException {
        ServerPlayer p = EntityArgument.getPlayer(c, "jugador");
        MinecraftServer server = c.getSource().getServer();
        EliminadosData.get(server).remove(p.getUUID());
        p.setGameMode(modo);
        p.setHealth(p.getMaxHealth());
        p.getFoodData().setFoodLevel(20);
        Anuncios.chat(server, Component.literal("\u2728 " + p.getGameProfile().getName() + " volvio al Dedsafio").withStyle(ChatFormatting.GREEN));
        return 1;
    }

    private static int eliminar(CommandContext<CommandSourceStack> c) throws CommandSyntaxException {
        ServerPlayer p = EntityArgument.getPlayer(c, "jugador");
        EliminadosData.get(c.getSource().getServer()).add(p.getUUID());
        p.setGameMode(GameType.SPECTATOR);
        Anuncios.chat(c.getSource().getServer(), Component.literal("\u2620 " + p.getGameProfile().getName() + " fue eliminado del Dedsafio").withStyle(ChatFormatting.RED));
        return 1;
    }

    private static int listar(CommandContext<CommandSourceStack> c) {
        MinecraftServer server = c.getSource().getServer();
        Set<UUID> todos = EliminadosData.get(server).all();
        GameProfileCache cache = server.getProfileCache();
        StringBuilder sb = new StringBuilder();
        for (UUID u : todos) {
            String nombre = cache == null ? u.toString() : cache.get(u).map(GameProfile::getName).orElse(u.toString());
            if (sb.length() > 0) sb.append(", ");
            sb.append(nombre);
        }
        String texto = todos.isEmpty() ? "No hay eliminados." : "Eliminados (" + todos.size() + "): " + sb;
        c.getSource().sendSuccess(() -> Component.literal(texto), false);
        return todos.size();
    }

    private static int dificultad(CommandContext<CommandSourceStack> c) {
        Difficulty dif = switch (StringArgumentType.getString(c, "nivel").toLowerCase()) {
            case "pacifico" -> Difficulty.PEACEFUL;
            case "facil" -> Difficulty.EASY;
            case "normal" -> Difficulty.NORMAL;
            case "dificil" -> Difficulty.HARD;
            default -> null;
        };
        if (dif == null) { c.getSource().sendFailure(Component.literal("Usa: pacifico, facil, normal o dificil")); return 0; }
        MinecraftServer server = c.getSource().getServer();
        server.setDifficulty(dif, true);
        Anuncios.titulo(server, Component.literal("CAMBIO DE DIFICULTAD").withStyle(ChatFormatting.RED),
                Component.literal("Ahora: " + dif.getDisplayName().getString()));
        return 1;
    }

    private static int ruleta(CommandContext<CommandSourceStack> c) {
        if (Ruleta.girando()) { c.getSource().sendFailure(Component.literal("La ruleta ya esta girando")); return 0; }
        if (!Ruleta.iniciar(c.getSource().getServer())) {
            c.getSource().sendFailure(Component.literal("La ruleta no tiene opciones en la config"));
            return 0;
        }
        return 1;
    }

    /** Construye una arena circular de blackstone y suelta al Guardian del Desafio. */
    private static int arena(CommandContext<CommandSourceStack> c) throws CommandSyntaxException {
        ServerPlayer p = c.getSource().getPlayerOrException();
        ServerLevel lvl = p.serverLevel();
        BlockPos centro = p.blockPosition();
        BlockState piso = Blocks.POLISHED_BLACKSTONE_BRICKS.defaultBlockState();
        BlockState centroPiso = Blocks.GILDED_BLACKSTONE.defaultBlockState();
        BlockState pared = Blocks.BLACKSTONE.defaultBlockState();
        BlockState aire = Blocks.AIR.defaultBlockState();
        int radio = 16;
        for (int dx = -radio; dx <= radio; dx++) {
            for (int dz = -radio; dz <= radio; dz++) {
                double dist = Math.sqrt(dx * dx + dz * dz);
                if (dist > radio + 0.5) continue;
                lvl.setBlock(centro.offset(dx, -1, dz), dist < 3 ? centroPiso : piso, 3);
                boolean borde = dist >= radio - 1;
                for (int dy = 0; dy <= 8; dy++) {
                    lvl.setBlock(centro.offset(dx, dy, dz), (borde && dy <= 6) ? pared : aire, 3);
                }
            }
        }
        for (int i = 0; i < 8; i++) {
            double ang = i * Math.PI / 4.0;
            int lx = (int) Math.round(Math.cos(ang) * radio);
            int lz = (int) Math.round(Math.sin(ang) * radio);
            lvl.setBlock(centro.offset(lx, 3, lz), Blocks.SHROOMLIGHT.defaultBlockState(), 3);
        }
        GuardianDesafio boss = ModEntities.GUARDIAN.get().create(lvl);
        if (boss == null) { c.getSource().sendFailure(Component.literal("No se pudo crear al boss")); return 0; }
        boss.moveTo(centro.getX() + 0.5, centro.getY(), centro.getZ() + 0.5, 0.0F, 0.0F);
        boss.setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(ModItems.ESPADA_DEDITA.get()));
        boss.setItemSlot(EquipmentSlot.HEAD, new ItemStack(ModItems.CASCO_DEDITA.get()));
        boss.setItemSlot(EquipmentSlot.CHEST, new ItemStack(ModItems.PETO_DEDITA.get()));
        boss.setItemSlot(EquipmentSlot.LEGS, new ItemStack(ModItems.PANTALONES_DEDITA.get()));
        boss.setItemSlot(EquipmentSlot.FEET, new ItemStack(ModItems.BOTAS_DEDITA.get()));
        for (EquipmentSlot slot : EquipmentSlot.values()) boss.setDropChance(slot, 0.0F);
        boss.setPersistenceRequired();
        lvl.addFreshEntity(boss);
        p.teleportTo(centro.getX() + 0.5, centro.getY(), centro.getZ() + 12.5);
        Anuncios.titulo(c.getSource().getServer(), Component.literal("EL GUARDIAN DESPIERTA").withStyle(ChatFormatting.DARK_RED),
                Component.literal("Que gane el mejor"));
        return 1;
    }

    /** Teletransporta a una de las dimensiones del mod (o al overworld). */
    private static int ir(CommandContext<CommandSourceStack> c) throws CommandSyntaxException {
        ServerPlayer p = c.getSource().getPlayerOrException();
        MinecraftServer server = c.getSource().getServer();
        String destino = StringArgumentType.getString(c, "destino").toLowerCase();
        ResourceKey<Level> key = switch (destino) {
            case "limbo" -> ResourceKey.create(Registries.DIMENSION, new ResourceLocation(DedsafioServer.MODID, "limbo"));
            case "islas" -> ResourceKey.create(Registries.DIMENSION, new ResourceLocation(DedsafioServer.MODID, "islas"));
            case "overworld" -> Level.OVERWORLD;
            default -> null;
        };
        if (key == null) { c.getSource().sendFailure(Component.literal("Destinos: limbo, islas, overworld")); return 0; }
        ServerLevel lvl = server.getLevel(key);
        if (lvl == null) { c.getSource().sendFailure(Component.literal("Esa dimension no esta cargada")); return 0; }
        BlockPos base = key == Level.OVERWORLD ? lvl.getSharedSpawnPos() : new BlockPos(0, 0, 0);
        BlockPos top = lvl.getHeightmapPos(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, base);
        int y = top.getY();
        if (y <= lvl.getMinBuildHeight() + 1) {
            y = 120;
            for (int dx = -2; dx <= 2; dx++) {
                for (int dz = -2; dz <= 2; dz++) {
                    lvl.setBlock(new BlockPos(base.getX() + dx, y - 1, base.getZ() + dz), Blocks.STONE_BRICKS.defaultBlockState(), 3);
                    for (int dy = 0; dy < 3; dy++) {
                        lvl.setBlock(new BlockPos(base.getX() + dx, y + dy, base.getZ() + dz), Blocks.AIR.defaultBlockState(), 3);
                    }
                }
            }
        }
        p.teleportTo(lvl, base.getX() + 0.5, y, base.getZ() + 0.5, p.getYRot(), p.getXRot());
        return 1;
    }
}
