package com.dedsafio.server;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.StringTag;
import net.minecraft.nbt.Tag;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.level.saveddata.SavedData;

/** Saldos de deditas y correo entre jugadores, guardados en el mundo. */
public class EconomiaData extends SavedData {
    private final Map<UUID, Integer> saldos = new HashMap<>();
    private final Map<UUID, List<String>> correo = new HashMap<>();

    public static EconomiaData get(MinecraftServer server) {
        return server.overworld().getDataStorage().computeIfAbsent(EconomiaData::load, EconomiaData::new, "dedsafio_economia");
    }

    public static EconomiaData load(CompoundTag tag) {
        EconomiaData d = new EconomiaData();
        CompoundTag s = tag.getCompound("saldos");
        for (String k : s.getAllKeys()) d.saldos.put(UUID.fromString(k), s.getInt(k));
        CompoundTag c = tag.getCompound("correo");
        for (String k : c.getAllKeys()) {
            ListTag l = c.getList(k, Tag.TAG_STRING);
            List<String> msgs = new ArrayList<>();
            for (int i = 0; i < l.size(); i++) msgs.add(l.getString(i));
            d.correo.put(UUID.fromString(k), msgs);
        }
        return d;
    }

    @Override
    public CompoundTag save(CompoundTag tag) {
        CompoundTag s = new CompoundTag();
        saldos.forEach((k, v) -> s.putInt(k.toString(), v));
        tag.put("saldos", s);
        CompoundTag c = new CompoundTag();
        correo.forEach((k, v) -> {
            ListTag l = new ListTag();
            for (String m : v) l.add(StringTag.valueOf(m));
            c.put(k.toString(), l);
        });
        tag.put("correo", c);
        return tag;
    }

    public int saldo(UUID u) { return saldos.getOrDefault(u, 0); }

    public void sumar(UUID u, int n) { saldos.put(u, saldo(u) + n); setDirty(); }

    public boolean restar(UUID u, int n) {
        if (saldo(u) < n) return false;
        saldos.put(u, saldo(u) - n);
        setDirty();
        return true;
    }

    public void enviar(UUID para, String mensaje) {
        correo.computeIfAbsent(para, k -> new ArrayList<>()).add(mensaje);
        setDirty();
    }

    public int cartas(UUID u) { return correo.getOrDefault(u, List.of()).size(); }

    public List<String> vaciar(UUID u) {
        List<String> l = correo.remove(u);
        setDirty();
        return l == null ? List.of() : l;
    }
}
