package com.dedsafio.server;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.game.ClientboundSetActionBarTextPacket;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.server.ServerLifecycleHooks;

/** Ruleta animada en la barra de accion + eventos automaticos. */
@Mod.EventBusSubscriber(modid = DedsafioServer.MODID)
public class Ruleta {
    private static final int[] RETRASOS = {2, 2, 2, 2, 2, 3, 3, 4, 4, 5, 6, 8, 10, 12, 15, 24};
    private static boolean girando = false;
    private static List<String> opciones = new ArrayList<>();
    private static int paso, espera, indice, ticksAuto;

    public static boolean girando() { return girando; }

    public static boolean iniciar(MinecraftServer server) {
        if (girando) return false;
        List<? extends String> ops = Config.RULETA.get();
        if (ops.isEmpty()) return false;
        opciones = new ArrayList<>(ops);
        int objetivo = server.overworld().random.nextInt(opciones.size());
        indice = Math.floorMod(objetivo - (RETRASOS.length - 1), opciones.size());
        paso = 0;
        espera = 1;
        girando = true;
        return true;
    }

    @SubscribeEvent
    public static void tick(TickEvent.ServerTickEvent e) {
        if (e.phase != TickEvent.Phase.END) return;
        MinecraftServer server = ServerLifecycleHooks.getCurrentServer();
        if (server == null) return;
        if (!girando) { auto(server); return; }
        if (--espera > 0) return;

        String actual = opciones.get(indice);
        String texto = actual.split("=>", 2)[0].trim();
        boolean ultimo = paso == RETRASOS.length - 1;
        Component barra = Component.literal(">> " + texto + " <<").withStyle(ultimo ? ChatFormatting.GOLD : ChatFormatting.YELLOW);
        for (ServerPlayer p : server.getPlayerList().getPlayers()) {
            p.connection.send(new ClientboundSetActionBarTextPacket(barra));
            p.playNotifySound(ultimo ? SoundEvents.PLAYER_LEVELUP : SoundEvents.EXPERIENCE_ORB_PICKUP, SoundSource.MASTER, 1.0F, ultimo ? 1.0F : 1.3F);
        }
        if (ultimo) {
            girando = false;
            aplicar(server, actual);
            return;
        }
        espera = RETRASOS[paso];
        paso++;
        indice = (indice + 1) % opciones.size();
    }

    private static void auto(MinecraftServer server) {
        int minutos = Config.EVENTO_AUTO_MINUTOS.get();
        if (minutos <= 0 || server.getPlayerCount() == 0) { ticksAuto = 0; return; }
        if (++ticksAuto >= minutos * 1200) {
            ticksAuto = 0;
            iniciar(server);
        }
    }

    public static void aplicar(MinecraftServer server, String elegida) {
        String[] partes = elegida.split("=>", 2);
        Anuncios.titulo(server, Component.literal("LA RULETA DECIDIO").withStyle(ChatFormatting.GOLD),
                Component.literal(partes[0].trim()).withStyle(ChatFormatting.YELLOW));
        if (partes.length == 2) {
            String cmd = partes[1].trim();
            if (cmd.startsWith("/")) cmd = cmd.substring(1);
            server.getCommands().performPrefixedCommand(server.createCommandSourceStack().withSuppressedOutput(), cmd);
        }
    }
}
