package com.dedsafio.server;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerBossEvent;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.BossEvent;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.monster.Zombie;
import net.minecraft.world.level.Level;

/** Mini boss: un zombi gigante con barra de jefe, fase de furia y refuerzos. */
public class GuardianDesafio extends Zombie {
    private final ServerBossEvent bossEvent = new ServerBossEvent(
            Component.literal("Guardian del Desafio"), BossEvent.BossBarColor.RED, BossEvent.BossBarOverlay.NOTCHED_10);
    private boolean furia = false;

    public GuardianDesafio(EntityType<? extends Zombie> type, Level level) {
        super(type, level);
        this.xpReward = 200;
    }

    public static AttributeSupplier.Builder atributos() {
        return Zombie.createAttributes()
                .add(Attributes.MAX_HEALTH, 300.0D)
                .add(Attributes.ATTACK_DAMAGE, 12.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.27D)
                .add(Attributes.ARMOR, 10.0D)
                .add(Attributes.KNOCKBACK_RESISTANCE, 0.8D)
                .add(Attributes.FOLLOW_RANGE, 48.0D)
                .add(Attributes.SPAWN_REINFORCEMENTS_CHANCE, 0.0D);
    }

    @Override public boolean isBaby() { return false; }
    @Override protected boolean isSunSensitive() { return false; }
    @Override protected boolean convertsInWater() { return false; }
    @Override public boolean removeWhenFarAway(double distance) { return false; }

    @Override
    protected void customServerAiStep() {
        super.customServerAiStep();
        bossEvent.setProgress(this.getHealth() / this.getMaxHealth());
        if (!furia && this.getHealth() < this.getMaxHealth() / 2.0F) {
            furia = true;
            this.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST, 20 * 600, 1));
            this.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 20 * 600, 0));
            if (this.level().getServer() != null) {
                Anuncios.chat(this.level().getServer(), Component.literal("El Guardian del Desafio entro en furia!").withStyle(ChatFormatting.DARK_RED));
            }
        }
        if (this.tickCount % 400 == 0 && this.getTarget() != null && this.level() instanceof ServerLevel sl) {
            for (int i = 0; i < 2; i++) {
                EntityType.ZOMBIE.spawn(sl, this.blockPosition().offset(i * 2 - 1, 0, 2), MobSpawnType.MOB_SUMMONED);
            }
        }
    }

    @Override
    public void startSeenByPlayer(ServerPlayer player) {
        super.startSeenByPlayer(player);
        bossEvent.addPlayer(player);
    }

    @Override
    public void stopSeenByPlayer(ServerPlayer player) {
        super.stopSeenByPlayer(player);
        bossEvent.removePlayer(player);
    }

    @Override
    public void die(DamageSource source) {
        super.die(source);
        if (this.level().getServer() != null) {
            Anuncios.chat(this.level().getServer(), Component.literal("El Guardian del Desafio fue derrotado!").withStyle(ChatFormatting.GOLD));
        }
    }
}
