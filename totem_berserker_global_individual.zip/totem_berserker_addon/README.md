# Totem Berserker — Forge 1.20.1

Addon independiente para Minecraft Java 1.20.1 + Forge 47.2.0.

## Funcionamiento
- El sistema está desactivado por defecto.
- Un administrador puede activarlo con `/berserker on`.
- Cuando CUALQUIER jugador activa/consume un Tótem de la Inmortalidad mientras el sistema está activo, comienza un efecto global de 100 ticks (5 segundos).
- Durante esos 5 segundos, TODO el daño recibido por TODOS los jugadores se multiplica por 2.5.
- Incluye daño de mobs, jugadores, proyectiles, caídas, lava, fuego, explosiones y otras fuentes de daño procesadas por `LivingHurtEvent`.
- No aumenta el daño que hacen los jugadores ni modifica el daño recibido por mobs.
- Si cualquier jugador consume otro tótem mientras el efecto está activo, los 5 segundos globales se reinician.
- El efecto y el interruptor global se guardan en los datos del mundo.
- El multiplicador utiliza el tiempo del Overworld para que la duración sea compartida entre todas las dimensiones.

## Modo individual
- Interruptor independiente del modo global, desactivado por defecto.
- Con `/berserker individual on`, cuando un jugador consume un tótem, SOLO ese jugador recibe x2,5 de daño durante 5 segundos (se reinicia si consume otro).
- Los dos modos pueden estar activos a la vez: si ambos aplican a un jugador, el x2,5 se aplica una sola vez (no se acumula).

## Comandos
Requieren nivel de permiso 2 (OP):
- `/berserker on` — activa el modo GLOBAL.
- `/berserker off` — desactiva el modo global y cancela el efecto actual.
- `/berserker toggle` — cambia el estado del modo global.
- `/berserker individual on` — activa el modo INDIVIDUAL.
- `/berserker individual off` — desactiva el modo individual y cancela los efectos individuales.
- `/berserker individual toggle` — cambia el estado del modo individual.
- `/berserker status` — muestra el estado de ambos modos y cuánto dura el efecto actual.

## Instalación
1. Compilar el proyecto con Java 17 y Gradle 8.x.
2. Ejecutar `gradle build`.
3. El JAR queda en `build/libs/totem_berserker-1.0.0.jar`.
4. Colocar el JAR en `mods` tanto del cliente como del servidor.

## Compilación en Windows
Instalar un JDK 17 y Gradle 8.x. Abrir una terminal dentro de esta carpeta y ejecutar:

```bat
gradle build
```

El proyecto descarga ForgeGradle y Forge desde los repositorios configurados, por lo que necesita conexión a Internet durante la primera compilación.

## Notas
- No modifica ningún mod existente.
- El efecto se aplica al daño recibido por entidades `ServerPlayer`; el daño a mobs no se multiplica.
- El multiplicador actúa en el evento `LivingHurtEvent` de Forge, por lo que se aplica a las fuentes de daño que atraviesan ese evento.
- Probar primero en una copia del mundo/servidor antes de usarlo en producción.
