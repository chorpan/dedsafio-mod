package com.chorpan.totemberserker;

import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

@Mod(TotemBerserker.MOD_ID)
public class TotemBerserker {
    public static final String MOD_ID = "totem_berserker";

    public TotemBerserker() {
        IEventBus modBus = FMLJavaModLoadingContext.get().getModEventBus();
        MinecraftForge.EVENT_BUS.register(new BerserkerEvents());
        MinecraftForge.EVENT_BUS.register(new BerserkerCommands());
    }
}
