package com.chorpan.totemberserker;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.saveddata.SavedData;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class BerserkerSavedData extends SavedData {
    private static final String DATA_NAME = "totem_berserker_state";
    private boolean enabled = false;
    private long globalDamageBoostUntil = 0L;

    // Modo individual: interruptor propio + ventana de daño por jugador.
    private boolean individualEnabled = false;
    private final Map<UUID, Long> individualBoostUntil = new HashMap<>();

    public static BerserkerSavedData get(ServerLevel anyLevel) {
        ServerLevel overworld = anyLevel.getServer().overworld();
        return overworld.getDataStorage().computeIfAbsent(
                BerserkerSavedData::load,
                BerserkerSavedData::new,
                DATA_NAME
        );
    }

    public static BerserkerSavedData load(CompoundTag tag) {
        BerserkerSavedData data = new BerserkerSavedData();
        data.enabled = tag.getBoolean("Enabled");
        data.globalDamageBoostUntil = tag.getLong("GlobalDamageBoostUntil");
        data.individualEnabled = tag.getBoolean("IndividualEnabled");
        ListTag list = tag.getList("IndividualBoosts", Tag.TAG_COMPOUND);
        for (int i = 0; i < list.size(); i++) {
            CompoundTag entry = list.getCompound(i);
            data.individualBoostUntil.put(entry.getUUID("Player"), entry.getLong("Until"));
        }
        return data;
    }

    public boolean isEnabled() {
        return enabled;
    }

    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
        if (!enabled) {
            this.globalDamageBoostUntil = 0L;
        }
        setDirty();
    }

    public boolean toggle() {
        setEnabled(!enabled);
        return enabled;
    }

    /** Starts/restarts the global increased-damage window. Time is measured using Overworld game time. */
    public void startGlobalDamageBoost(long overworldGameTime, long durationTicks) {
        this.globalDamageBoostUntil = overworldGameTime + durationTicks;
        setDirty();
    }

    public boolean isGlobalDamageBoostActive(long overworldGameTime) {
        return enabled && globalDamageBoostUntil > overworldGameTime;
    }

    public long getGlobalDamageBoostTicksRemaining(long overworldGameTime) {
        return Math.max(0L, globalDamageBoostUntil - overworldGameTime);
    }

    // ---------- Modo individual ----------

    public boolean isIndividualEnabled() {
        return individualEnabled;
    }

    public void setIndividualEnabled(boolean individualEnabled) {
        this.individualEnabled = individualEnabled;
        if (!individualEnabled) {
            this.individualBoostUntil.clear();
        }
        setDirty();
    }

    public boolean toggleIndividual() {
        setIndividualEnabled(!individualEnabled);
        return individualEnabled;
    }

    /** Starts/restarts the increased-damage window of ONE player. */
    public void startIndividualDamageBoost(UUID player, long overworldGameTime, long durationTicks) {
        this.individualBoostUntil.put(player, overworldGameTime + durationTicks);
        setDirty();
    }

    public boolean isIndividualDamageBoostActive(UUID player, long overworldGameTime) {
        return individualEnabled && individualBoostUntil.getOrDefault(player, 0L) > overworldGameTime;
    }

    public long getIndividualDamageBoostTicksRemaining(UUID player, long overworldGameTime) {
        return Math.max(0L, individualBoostUntil.getOrDefault(player, 0L) - overworldGameTime);
    }

    @Override
    public CompoundTag save(CompoundTag tag) {
        tag.putBoolean("Enabled", enabled);
        tag.putLong("GlobalDamageBoostUntil", globalDamageBoostUntil);
        tag.putBoolean("IndividualEnabled", individualEnabled);
        ListTag list = new ListTag();
        for (Map.Entry<UUID, Long> e : individualBoostUntil.entrySet()) {
            CompoundTag entry = new CompoundTag();
            entry.putUUID("Player", e.getKey());
            entry.putLong("Until", e.getValue());
            list.add(entry);
        }
        tag.put("IndividualBoosts", list);
        return tag;
    }
}
