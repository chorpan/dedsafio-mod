package com.chorpan.totemberserker;

import com.mojang.brigadier.Command;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

public class BerserkerCommands {
    @SubscribeEvent
    public void onRegisterCommands(RegisterCommandsEvent event) {
        event.getDispatcher().register(
                Commands.literal("berserker")
                        .requires(source -> source.hasPermission(2))
                        .then(Commands.literal("on").executes(context -> {
                            ServerLevel level = context.getSource().getServer().overworld();
                            BerserkerSavedData.get(level).setEnabled(true);
                            context.getSource().sendSuccess(
                                    () -> Component.literal("[Berserker] Sistema ACTIVADO. Cada tótem activa 5 segundos de daño recibido x2,5 para TODO el servidor."), true);
                            return Command.SINGLE_SUCCESS;
                        }))
                        .then(Commands.literal("off").executes(context -> {
                            ServerLevel level = context.getSource().getServer().overworld();
                            BerserkerSavedData.get(level).setEnabled(false);
                            context.getSource().sendSuccess(
                                    () -> Component.literal("[Berserker] Sistema DESACTIVADO y efecto global cancelado."), true);
                            return Command.SINGLE_SUCCESS;
                        }))
                        .then(Commands.literal("toggle").executes(context -> {
                            ServerLevel level = context.getSource().getServer().overworld();
                            boolean enabled = BerserkerSavedData.get(level).toggle();
                            context.getSource().sendSuccess(
                                    () -> Component.literal("[Berserker] Sistema " + (enabled ? "ACTIVADO" : "DESACTIVADO") + "."), true);
                            return Command.SINGLE_SUCCESS;
                        }))
                        .then(Commands.literal("individual")
                                .then(Commands.literal("on").executes(context -> {
                                    ServerLevel level = context.getSource().getServer().overworld();
                                    BerserkerSavedData.get(level).setIndividualEnabled(true);
                                    context.getSource().sendSuccess(
                                            () -> Component.literal("[Berserker] Modo INDIVIDUAL ACTIVADO. Cada tótem activa 5 segundos de daño recibido x2,5 solo para quien lo consume."), true);
                                    return Command.SINGLE_SUCCESS;
                                }))
                                .then(Commands.literal("off").executes(context -> {
                                    ServerLevel level = context.getSource().getServer().overworld();
                                    BerserkerSavedData.get(level).setIndividualEnabled(false);
                                    context.getSource().sendSuccess(
                                            () -> Component.literal("[Berserker] Modo INDIVIDUAL DESACTIVADO y efectos individuales cancelados."), true);
                                    return Command.SINGLE_SUCCESS;
                                }))
                                .then(Commands.literal("toggle").executes(context -> {
                                    ServerLevel level = context.getSource().getServer().overworld();
                                    boolean enabled = BerserkerSavedData.get(level).toggleIndividual();
                                    context.getSource().sendSuccess(
                                            () -> Component.literal("[Berserker] Modo INDIVIDUAL " + (enabled ? "ACTIVADO" : "DESACTIVADO") + "."), true);
                                    return Command.SINGLE_SUCCESS;
                                }))
                        )
                        .then(Commands.literal("status").executes(context -> {
                            ServerLevel level = context.getSource().getServer().overworld();
                            BerserkerSavedData data = BerserkerSavedData.get(level);
                            long remaining = data.getGlobalDamageBoostTicksRemaining(level.getGameTime());
                            String effectStatus = remaining > 0
                                    ? String.format(java.util.Locale.ROOT, "ACTIVO (%.1f segundos restantes)", remaining / 20.0)
                                    : "inactivo";
                            String individualStatus = "";
                            if (context.getSource().getEntity() instanceof ServerPlayer p) {
                                long ind = data.getIndividualDamageBoostTicksRemaining(p.getUUID(), level.getGameTime());
                                individualStatus = ind > 0
                                        ? String.format(java.util.Locale.ROOT, "ACTIVO (%.1f segundos restantes)", ind / 20.0)
                                        : "inactivo";
                            }
                            String individualLine = " | Modo individual: " + (data.isIndividualEnabled() ? "ACTIVADO" : "DESACTIVADO")
                                    + (individualStatus.isEmpty() ? "" : " (tu efecto: " + individualStatus + ")");
                            context.getSource().sendSuccess(
                                    () -> Component.literal("[Berserker] Sistema global: " + (data.isEnabled() ? "ACTIVADO" : "DESACTIVADO") + " | Daño recibido global x2,5: " + effectStatus + individualLine), false);
                            return Command.SINGLE_SUCCESS;
                        }))
        );
    }
}
