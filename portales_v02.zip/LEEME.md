# Dedsafio Portales (Forge 1.20.1) — v0.1

## Como se construye un portal (todos iguales, cambian los bloques)
```
M M M M M      M = Marco del portal (16 bloques, todos del mismo tipo)
M . . . M      N = Nucleo del portal (1 bloque, al centro)
M . N . M      . = aire (interior libre, y libre tambien encima del nucleo)
M . . . M
M M M M M
```
Todo a la misma altura. Click derecho en el nucleo: se valida la estructura, se enciende y
tras 3 segundos (sin moverte) viajas. Si te alejas o mueres, se cancela.

## Progresion
| Portal | Conecta | Materiales (tags editables) | Requisito para ir adelante |
|---|---|---|---|
| 1 | Overworld ↔ Blue Skies (Everbright) | obsidiana, ladrillos de piedra, diamante | ninguno |
| 5 | Everbright ↔ Everdawn | materiales de Everbright (tags marco_materia_5 / base_5 / esencia_5, IDs sin verificar) | ninguno por defecto (config requisitos_portal_5) |
| 2 | Everdawn ↔ Undergarden | horizonita/falsita/charoita (Blue Skies) | matar Alchemist, Arachnarch, Summoner, Starlit Crusher |
| 3 | Undergarden ↔ Otherside | cloggrum/froststeel/utherium (Undergarden) | ninguno por ahora (falta confirmar IDs) |
| 4 | Otherside ↔ Zona final (Overworld) | eco reforzado, hueso sculk, corazon de las profundidades | matar Stalker y Warden |

- **Regreso obligatorio:** cada portal solo une SUS dos etapas. No hay forma de saltar etapas con portales del addon.
- **Portales originales:** se cancela cualquier viaje de dimension que entre o salga de Blue Skies, Undergarden,
  Otherside o la zona final y no venga de estos portales (sin editar esos mods). Ahora Everbright y Everdawn son etapas separadas: ir de una a otra solo se puede con el portal 5 (el numero 5 es solo el nombre de los bloques; en la progresion va segundo).
- **Por jugador:** etapa alcanzada, jefes derrotados y portal de origen se guardan por jugador en el mundo.
  El portal solo teletransporta a quien lo activa, nunca a acompanantes.
- Al llegar por primera vez a una etapa se genera un portal de llegada ya activado. Para volver, el jugador va al portal que uso
  para salir (o a uno de respaldo si fue destruido).
- **Zona final:** plataforma de blackstone en el Overworld, lejos del spawn (config: zona_final_x / zona_final_z).

## Config (config del mundo, carpeta serverconfig)
requisitos_portal_1..5, zona_final_x/z, jefes_zona_final (IDs de jefes que aparecen al crear la zona final),
admin_viaja_libre (solo pruebas, apagado por defecto).

## Pendientes / limitaciones
- Faltan los jars de The Undergarden y L_Ender's Cataclysm: no pude verificar sus IDs de items ni de jefes.
  Los items del Undergarden en las recetas del portal 3 y los jefes de Cataclysm son suposiciones: confirmar.
- Las recetas se pueden cambiar con un datapack editando los tags `dedsafio_portals:*` (marco_materia_N, base_N, esencia_N).
- Una zona final con jefes de Cataclysm requiere los IDs reales (ponerlos en jefes_zona_final).
- Sin probar: el codigo no se pudo compilar ni ejecutar donde fue escrito.
