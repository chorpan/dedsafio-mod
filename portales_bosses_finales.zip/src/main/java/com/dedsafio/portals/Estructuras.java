package com.dedsafio.portals;

import java.util.Optional;

import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.levelgen.structure.templatesystem.StructurePlaceSettings;
import net.minecraft.world.level.levelgen.structure.templatesystem.StructureTemplate;

/** Carga y pega las estructuras NBT incluidas en el mod. */
public final class Estructuras {
    private Estructuras() {}

    public static boolean colocar(ServerLevel level, BlockPos origen, String nombre) {
        ResourceLocation id = new ResourceLocation(PortalesMod.MODID, nombre);
        Optional<StructureTemplate> opt = level.getStructureManager().get(id);
        if (opt.isEmpty()) return false;
        StructureTemplate template = opt.get();
        StructurePlaceSettings settings = new StructurePlaceSettings()
                .setIgnoreEntities(true)
                .setKnownShape(true)
                .setKeepLiquids(true);
        return template.placeInWorld(level, origen, origen, settings, level.random, 3);
    }
}
