package com.dedsafio.portals;

import java.util.UUID;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.Registries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.Tag;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.saveddata.SavedData;

/** Progreso por jugador, destinos y estado global de los jefes. */
public class PortalesData extends SavedData {
    public record Punto(ResourceKey<Level> dim, BlockPos pos) {}

    private CompoundTag jugadores = new CompoundTag();
    private CompoundTag destinos = new CompoundTag();
    private CompoundTag jefes = new CompoundTag();

    public static PortalesData get(MinecraftServer server) {
        return server.overworld().getDataStorage().computeIfAbsent(PortalesData::load, PortalesData::new, "dedsafio_portales");
    }

    public static PortalesData load(CompoundTag tag) {
        PortalesData d = new PortalesData();
        d.jugadores = tag.getCompound("jugadores");
        d.destinos = tag.getCompound("destinos");
        d.jefes = tag.getCompound("jefes");
        return d;
    }

    @Override
    public CompoundTag save(CompoundTag tag) {
        tag.put("jugadores", jugadores);
        tag.put("destinos", destinos);
        tag.put("jefes", jefes);
        return tag;
    }

    private CompoundTag j(UUID u) {
        String k = u.toString();
        if (!jugadores.contains(k, Tag.TAG_COMPOUND)) jugadores.put(k, new CompoundTag());
        return jugadores.getCompound(k);
    }

    public int etapaMax(UUID u) { return j(u).getInt("etapa"); }

    public void subirEtapa(UUID u, int etapa) {
        CompoundTag t = j(u);
        if (etapa > t.getInt("etapa")) {
            t.putInt("etapa", etapa);
            setDirty();
        }
    }

    public boolean derroto(UUID u, String entidad) { return j(u).getCompound("derrotados").getBoolean(entidad); }

    public boolean registrarKill(UUID u, String entidad) {
        CompoundTag t = j(u);
        CompoundTag der = t.getCompound("derrotados");
        if (der.getBoolean(entidad)) return false;
        der.putBoolean(entidad, true);
        t.put("derrotados", der);
        setDirty();
        return true;
    }

    public void guardarOrigen(UUID u, PortalTipo tipo, ResourceKey<Level> dim, BlockPos pos) {
        CompoundTag t = j(u);
        CompoundTag os = t.getCompound("origenes");
        os.put("p" + tipo.numero, aTag(new Punto(dim, pos)));
        t.put("origenes", os);
        setDirty();
    }

    public Punto origen(UUID u, PortalTipo tipo) {
        CompoundTag os = j(u).getCompound("origenes");
        String k = "p" + tipo.numero;
        return os.contains(k, Tag.TAG_COMPOUND) ? deTag(os.getCompound(k)) : null;
    }

    public Punto destino(String clave) {
        return destinos.contains(clave, Tag.TAG_COMPOUND) ? deTag(destinos.getCompound(clave)) : null;
    }

    public void guardarDestino(String clave, Punto p) {
        destinos.put(clave, aTag(p));
        setDirty();
    }

    public boolean jefeFlag(String clave) { return jefes.getBoolean(clave); }

    public void setJefeFlag(String clave, boolean valor) {
        jefes.putBoolean(clave, valor);
        setDirty();
    }

    public UUID jefeUuid(String clave) {
        if (!jefes.contains(clave, Tag.TAG_STRING)) return null;
        try { return UUID.fromString(jefes.getString(clave)); }
        catch (IllegalArgumentException e) { return null; }
    }

    public void setJefeUuid(String clave, UUID uuid) {
        if (uuid == null) jefes.remove(clave);
        else jefes.putString(clave, uuid.toString());
        setDirty();
    }

    private static CompoundTag aTag(Punto p) {
        CompoundTag t = new CompoundTag();
        t.putString("dim", p.dim().location().toString());
        t.putInt("x", p.pos().getX());
        t.putInt("y", p.pos().getY());
        t.putInt("z", p.pos().getZ());
        return t;
    }

    private static Punto deTag(CompoundTag t) {
        ResourceKey<Level> dim = ResourceKey.create(Registries.DIMENSION, new ResourceLocation(t.getString("dim")));
        return new Punto(dim, new BlockPos(t.getInt("x"), t.getInt("y"), t.getInt("z")));
    }
}
