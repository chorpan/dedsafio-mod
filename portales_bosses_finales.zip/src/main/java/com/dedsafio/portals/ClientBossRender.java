package com.dedsafio.portals;

import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.LivingEntityRenderer;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.monster.warden.Warden;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderLivingEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Hace visualmente gigante al Warden final sin cambiar el comportamiento vanilla del Warden. */
@Mod.EventBusSubscriber(modid = PortalesMod.MODID, value = Dist.CLIENT)
public final class ClientBossRender {
    private ClientBossRender() {}

    @SubscribeEvent
    public static void escalarWarden(RenderLivingEvent.Pre<? extends LivingEntity, ?> event) {
        LivingEntity entity = event.getEntity();
        if (entity instanceof Warden && entity.getPersistentData().getBoolean("DedsafioFinalBoss")) {
            event.getPoseStack().scale(3.0F, 3.0F, 3.0F);
        }
    }
}
