package com.dedsafio.portals;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerBossEvent;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.BossEvent;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.monster.warden.Warden;
import net.minecraft.world.item.EnchantmentHelper;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.enchantment.Enchantments;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.registries.ForgeRegistries;

/** Jefes, barras de vida y recompensas de las dos zonas de desafio. */
@Mod.EventBusSubscriber(modid = PortalesMod.MODID)
public final class Bosses {
    private static final String FINAL_BOSS = "DedsafioFinalBoss";
    private static final String UNDER_BOSS = "DedsafioUndergardenBoss";
    private static final String FINAL_UUID = "final_boss_uuid";
    private static final String UNDER_UUID = "undergarden_boss_uuid";
    private static final String FINAL_DEAD = "final_boss_derrotado";
    private static final String UNDER_DEAD = "undergarden_boss_derrotado";
    private static final String FINAL_STRUCT = "final_estructura_creada";
    private static final String UNDER_STRUCT = "undergarden_estructura_creada";

    private static ServerBossEvent finalBar;
    private static ServerBossEvent underBar;

    private Bosses() {}

    public static void prepararFinal(MinecraftServer server, ServerLevel lvl, net.minecraft.core.BlockPos portal) {
        PortalesData d = PortalesData.get(server);
        if (!d.jefeFlag(FINAL_STRUCT)) {
            Estructuras.colocar(lvl, portal.offset(-40, 0, 0), "final_castle");
            PortalMundo.construir(lvl, portal, PortalTipo.P4);
            d.setJefeFlag(FINAL_STRUCT, true);
        }
        if (!d.jefeFlag(FINAL_DEAD) && d.jefeUuid(FINAL_UUID) == null) {
            BlockPos bossPos = portal.offset(0, 1, 58);
            Warden boss = EntityType.WARDEN.create(lvl);
            if (boss != null) {
                configurarWarden(boss, bossPos);
                lvl.addFreshEntity(boss);
                d.setJefeUuid(FINAL_UUID, boss.getUUID());
            }
        }
        actualizarBar(server, d, true);
    }

    public static void prepararUndergarden(MinecraftServer server, ServerLevel lvl, net.minecraft.core.BlockPos portal) {
        PortalesData d = PortalesData.get(server);
        if (!d.jefeFlag(UNDER_STRUCT)) {
            Estructuras.colocar(lvl, portal.offset(-30, 0, 0), "undergarden_ruin");
            PortalMundo.construir(lvl, portal, PortalTipo.P2);
            d.setJefeFlag(UNDER_STRUCT, true);
        }
        if (!d.jefeFlag(UNDER_DEAD) && d.jefeUuid(UNDER_UUID) == null) {
            BlockPos bossPos = portal.offset(0, 1, 40);
            Entity boss = crearEntidad(lvl, "undergarden:forgotten_guardian");
            if (boss instanceof Mob mob) {
                mob.moveTo(bossPos.getX() + 0.5, bossPos.getY(), bossPos.getZ() + 0.5, 0.0F, 0.0F);
                mob.getPersistentData().putBoolean(UNDER_BOSS, true);
                mob.setCustomName(Component.literal("Guardián de las Ruinas"));
                mob.setCustomNameVisible(true);
                mob.setPersistenceRequired();
                ajustarAtributo(mob, Attributes.MAX_HEALTH, 300.0D);
                ajustarAtributo(mob, Attributes.ATTACK_DAMAGE, 15.0D);
                ajustarAtributo(mob, Attributes.MOVEMENT_SPEED, 0.28D);
                ajustarAtributo(mob, Attributes.ARMOR, 14.0D);
                ajustarAtributo(mob, Attributes.ARMOR_TOUGHNESS, 6.0D);
                ajustarAtributo(mob, Attributes.KNOCKBACK_RESISTANCE, 1.0D);
                mob.setHealth(mob.getMaxHealth());
                lvl.addFreshEntity(mob);
                d.setJefeUuid(UNDER_UUID, mob.getUUID());
            }
        }
        actualizarBar(server, d, false);
    }

    private static void configurarWarden(Warden boss, BlockPos pos) {
        boss.moveTo(pos.getX() + 0.5, pos.getY(), pos.getZ() + 0.5, 0.0F, 0.0F);
        boss.getPersistentData().putBoolean(FINAL_BOSS, true);
        boss.setCustomName(Component.literal("El Guardián del Umbral"));
        boss.setCustomNameVisible(true);
        boss.setPersistenceRequired();
        ajustarAtributo(boss, Attributes.MAX_HEALTH, 1500.0D);
        // Mantiene el daño de combate del Warden; solo aumentamos vida, defensa y velocidad.
        ajustarAtributo(boss, Attributes.MOVEMENT_SPEED, 0.45D);
        ajustarAtributo(boss, Attributes.ARMOR, 20.0D);
        ajustarAtributo(boss, Attributes.ARMOR_TOUGHNESS, 10.0D);
        ajustarAtributo(boss, Attributes.KNOCKBACK_RESISTANCE, 1.0D);
        boss.setHealth(boss.getMaxHealth());
        boss.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, Integer.MAX_VALUE, 1, false, false));
    }

    private static Entity crearEntidad(ServerLevel lvl, String id) {
        ResourceLocation rl = ResourceLocation.tryParse(id);
        if (rl == null || !ForgeRegistries.ENTITY_TYPES.containsKey(rl)) return null;
        EntityType<?> type = ForgeRegistries.ENTITY_TYPES.getValue(rl);
        return type == null ? null : type.create(lvl);
    }

    private static void ajustarAtributo(LivingEntity e, net.minecraft.world.entity.ai.attributes.Attribute a, double valor) {
        AttributeInstance inst = e.getAttribute(a);
        if (inst != null) inst.setBaseValue(valor);
    }

    private static void actualizarBar(MinecraftServer server, PortalesData d, boolean finalBoss) {
        String uuidKey = finalBoss ? FINAL_UUID : UNDER_UUID;
        UUID uuid = d.jefeUuid(uuidKey);
        if (uuid == null) return;
        ResourceLocation dimId = finalBoss ? Etapa.dimension(Etapa.OVERWORLD).location() : Etapa.dimension(Etapa.UNDERGARDEN).location();
        ServerLevel lvl = server.getLevel(net.minecraft.resources.ResourceKey.create(net.minecraft.core.registries.Registries.DIMENSION, dimId));
        if (lvl == null) return;
        Entity e = lvl.getEntity(uuid);
        if (!(e instanceof LivingEntity living) || !living.isAlive()) return;

        ServerBossEvent bar = finalBoss ? finalBar : underBar;
        if (bar == null) {
            bar = new ServerBossEvent(
                    finalBoss ? Component.literal("El Guardián del Umbral") : Component.literal("Guardián de las Ruinas"),
                    finalBoss ? BossEvent.BossBarColor.PURPLE : BossEvent.BossBarColor.GREEN,
                    BossEvent.BossBarOverlay.PROGRESS);
            bar.setPlayBossMusic(finalBoss);
            if (finalBoss) finalBar = bar; else underBar = bar;
        }
        bar.setProgress(Math.max(0.0F, Math.min(1.0F, living.getHealth() / living.getMaxHealth())));
        bar.removeAllPlayers();
        for (ServerPlayer p : server.getPlayerList().getPlayers()) {
            if (p.serverLevel() == lvl) bar.addPlayer(p);
        }
    }

    @SubscribeEvent
    public static void tick(TickEvent.ServerTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        MinecraftServer server = net.minecraftforge.server.ServerLifecycleHooks.getCurrentServer();
        if (server == null || server.getTickCount() % 10 != 0) return;
        PortalesData d = PortalesData.get(server);
        if (!d.jefeFlag(FINAL_DEAD)) {
            actualizarBar(server, d, true);
            mantenerObjetivo(server, d, true);
        }
        if (!d.jefeFlag(UNDER_DEAD)) {
            actualizarBar(server, d, false);
            mantenerObjetivo(server, d, false);
        }
    }

    private static void mantenerObjetivo(MinecraftServer server, PortalesData d, boolean finalBoss) {
        UUID uuid = d.jefeUuid(finalBoss ? FINAL_UUID : UNDER_UUID);
        if (uuid == null) return;
        ServerLevel lvl = finalBoss ? server.overworld() : server.getLevel(Etapa.dimension(Etapa.UNDERGARDEN));
        if (lvl == null) return;
        Entity entity = lvl.getEntity(uuid);
        if (!(entity instanceof Mob mob) || !mob.isAlive()) return;
        ServerPlayer nearest = null;
        double best = 64.0D * 64.0D;
        for (ServerPlayer p : lvl.players()) {
            double dist = p.distanceToSqr(mob);
            if (dist < best) {
                best = dist;
                nearest = p;
            }
        }
        if (nearest != null && (mob.getTarget() == null || !mob.getTarget().isAlive())) mob.setTarget(nearest);
    }

    @SubscribeEvent
    public static void alMorir(LivingDeathEvent event) {
        LivingEntity e = event.getEntity();
        MinecraftServer server = e.getServer();
        if (server == null) return;
        CompoundTag data = e.getPersistentData();
        if (data.getBoolean(FINAL_BOSS)) {
            derrotado(server, true);
        } else if (data.getBoolean(UNDER_BOSS)) {
            derrotado(server, false);
        }
    }

    private static void derrotado(MinecraftServer server, boolean finalBoss) {
        PortalesData d = PortalesData.get(server);
        String deadKey = finalBoss ? FINAL_DEAD : UNDER_DEAD;
        if (d.jefeFlag(deadKey)) return;
        d.setJefeFlag(deadKey, true);
        d.setJefeUuid(finalBoss ? FINAL_UUID : UNDER_UUID, null);
        ServerBossEvent bar = finalBoss ? finalBar : underBar;
        if (bar != null) {
            bar.setProgress(0.0F);
            bar.removeAllPlayers();
            bar.setVisible(false);
            if (finalBoss) finalBar = null; else underBar = null;
        }
        for (ServerPlayer p : server.getPlayerList().getPlayers()) {
            ItemStack mochila = crearMochila(finalBoss);
            if (!p.getInventory().add(mochila) && !mochila.isEmpty()) {
                p.drop(mochila, false);
            }
            p.displayClientMessage(Component.literal(finalBoss
                    ? "Derrotaron al Guardián del Umbral. Recibiste una Mochila del Desafío."
                    : "Derrotaron al Guardián de las Ruinas. Recibiste una Mochila de las Ruinas."), false);
        }
    }

    private static ItemStack crearMochila(boolean finalBoss) {
        ItemStack bundle = new ItemStack(Items.BUNDLE);
        bundle.setHoverName(Component.literal(finalBoss ? "Mochila del Desafío Final" : "Mochila de las Ruinas"));
        ListTag items = new ListTag();
        int cantidad = finalBoss ? 3 + ThreadLocalRandom.current().nextInt(4) : 2 + ThreadLocalRandom.current().nextInt(3);
        for (int i = 0; i < cantidad; i++) {
            ItemStack loot = finalBoss ? lootFinal() : lootUndergarden();
            if (!loot.isEmpty()) items.add(loot.save(new CompoundTag()));
        }
        bundle.getOrCreateTag().put("Items", items);
        return bundle;
    }

    private static ItemStack lootFinal() {
        int roll = ThreadLocalRandom.current().nextInt(100);
        String id;
        int count = 1;
        if (roll < 8) {
            id = switch (ThreadLocalRandom.current().nextInt(4)) {
                case 0 -> "deeperdarker:warden_helmet";
                case 1 -> "deeperdarker:warden_chestplate";
                case 2 -> "deeperdarker:warden_leggings";
                default -> "deeperdarker:warden_boots";
            };
        } else if (roll < 18) {
            id = switch (ThreadLocalRandom.current().nextInt(3)) {
                case 0 -> "deeperdarker:warden_sword";
                case 1 -> "deeperdarker:warden_pickaxe";
                default -> "deeperdarker:warden_axe";
            };
        } else if (roll < 25) {
            id = ThreadLocalRandom.current().nextBoolean() ? "deeperdarker:heart_of_the_deep" : "deeperdarker:reinforced_echo_shard";
        } else if (roll < 38) {
            id = "deeperdarker:warden_upgrade_smithing_template";
        } else {
            id = switch (ThreadLocalRandom.current().nextInt(9)) {
                case 0 -> "deeperdarker:soul_dust";
                case 1 -> "deeperdarker:soul_crystal";
                case 2 -> "deeperdarker:sculk_bone";
                case 3 -> "deeperdarker:grime_ball";
                case 4 -> "minecraft:bone";
                case 5 -> "minecraft:coal";
                case 6 -> "minecraft:rotten_flesh";
                case 7 -> "minecraft:echo_shard";
                default -> "minecraft:sculk";
            };
            count = 1 + ThreadLocalRandom.current().nextInt(5);
        }
        ItemStack stack = item(id, count);
        if (!stack.isEmpty() && roll < 8) {
            EnchantmentHelper.setEnchantments(Map.of(
                    Enchantments.PROTECTION, 4,
                    Enchantments.UNBREAKING, 3,
                    Enchantments.MENDING, 1), stack);
        } else if (!stack.isEmpty() && roll >= 8 && roll < 18) {
            EnchantmentHelper.setEnchantments(Map.of(
                    Enchantments.SHARPNESS, 5,
                    Enchantments.UNBREAKING, 3,
                    Enchantments.MENDING, 1), stack);
        }
        return stack;
    }

    private static ItemStack lootUndergarden() {
        int roll = ThreadLocalRandom.current().nextInt(100);
        String id;
        int count = 1;
        if (roll < 10) {
            id = switch (ThreadLocalRandom.current().nextInt(3)) {
                case 0 -> "undergarden:forgotten_sword";
                case 1 -> "undergarden:forgotten_pickaxe";
                default -> "undergarden:forgotten_axe";
            };
        } else if (roll < 22) {
            id = "undergarden:forgotten_nugget";
            count = 2 + ThreadLocalRandom.current().nextInt(7);
        } else if (roll < 30) {
            id = switch (ThreadLocalRandom.current().nextInt(3)) {
                case 0 -> "undergarden:utherium_crystal";
                case 1 -> "undergarden:cloggrum_ingot";
                default -> "undergarden:froststeel_ingot";
            };
            count = 1 + ThreadLocalRandom.current().nextInt(3);
        } else {
            id = switch (ThreadLocalRandom.current().nextInt(7)) {
                case 0 -> "minecraft:iron_ingot";
                case 1 -> "minecraft:coal";
                case 2 -> "minecraft:bone";
                case 3 -> "minecraft:rotten_flesh";
                case 4 -> "minecraft:gold_nugget";
                case 5 -> "minecraft:cobblestone";
                default -> "minecraft:stick";
            };
            count = 2 + ThreadLocalRandom.current().nextInt(8);
        }
        ItemStack stack = item(id, count);
        if (!stack.isEmpty() && roll < 10) {
            EnchantmentHelper.setEnchantments(Map.of(Enchantments.SHARPNESS, 3, Enchantments.UNBREAKING, 2), stack);
        }
        return stack;
    }

    private static ItemStack item(String id, int count) {
        ResourceLocation rl = ResourceLocation.tryParse(id);
        if (rl == null) return ItemStack.EMPTY;
        Item item = ForgeRegistries.ITEMS.getValue(rl);
        if (item == null || item == Items.AIR) return ItemStack.EMPTY;
        return new ItemStack(item, count);
    }
}
