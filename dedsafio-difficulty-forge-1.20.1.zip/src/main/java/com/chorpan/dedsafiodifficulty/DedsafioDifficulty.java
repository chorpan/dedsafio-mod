package com.chorpan.dedsafiodifficulty;

import com.mojang.logging.LogUtils;
import net.minecraft.ChatFormatting;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.event.entity.living.LivingEvent;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.entity.player.PlayerEvent.PlayerLoggedInEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.slf4j.Logger;

@Mod(DedsafioDifficulty.MODID)
public class DedsafioDifficulty {
    public static final String MODID = "dedsafiodifficulty";
    private static final Logger LOGGER = LogUtils.getLogger();
    private static final ResourceLocation EVERBRIGHT = new ResourceLocation("blue_skies", "everbright");
    private static final ResourceLocation EVERDAWN = new ResourceLocation("blue_skies", "everdawn");
    private static final ResourceLocation OTHERSIDE = new ResourceLocation("deeperdarker", "otherside");

    public DedsafioDifficulty() {
        MinecraftForge.EVENT_BUS.register(this);
        LOGGER.info("Dedsafio Difficulty cargado.");
    }

    private static DifficultyData data(MinecraftServer server) {
        return server.overworld().getDataStorage().computeIfAbsent(
                DifficultyData::load, DifficultyData::new, DifficultyData.DATA_NAME);
    }

    @SubscribeEvent
    public void onRegisterCommands(RegisterCommandsEvent event) {
        event.getDispatcher().register(Commands.literal("dedsafio")
                .requires(source -> source.hasPermission(2))
                .then(Commands.literal("dificultad")
                        .then(Commands.literal("activar").executes(ctx -> {
                            data(ctx.getSource().getServer()).setEnabled(true);
                            ctx.getSource().sendSuccess(() -> Component.literal(
                                    "Dedsafio: dificultad progresiva ACTIVADA para todo el servidor.").withStyle(ChatFormatting.GREEN), true);
                            return 1;
                        }))
                        .then(Commands.literal("desactivar").executes(ctx -> {
                            data(ctx.getSource().getServer()).setEnabled(false);
                            ctx.getSource().sendSuccess(() -> Component.literal(
                                    "Dedsafio: dificultad progresiva DESACTIVADA para todo el servidor.").withStyle(ChatFormatting.RED), true);
                            return 1;
                        }))
                        .then(Commands.literal("estado").executes(ctx -> {
                            DifficultyData d = data(ctx.getSource().getServer());
                            String progress = d.hasStarted()
                                    ? String.format(java.util.Locale.ROOT, "%.1fx", d.getMultiplier())
                                    : "esperando a que alguien llegue a Everdawn (2.5x)";
                            ctx.getSource().sendSuccess(() -> Component.literal("Dedsafio: "
                                    + (d.isEnabled() ? "ACTIVADA" : "DESACTIVADA")
                                    + " | Daño: " + progress
                                    + " | Dimensiones posteriores descubiertas: " + d.getExtraDimensions()
                                    + " | Castillo final generado: " + (d.isFinalCastleGenerated() ? "sí" : "no"))
                                    .withStyle(ChatFormatting.AQUA), false);
                            return 1;
                        }))));
    }

    @SubscribeEvent
    public void onLogin(PlayerLoggedInEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer player)) return;
        if (player.level().dimension().location().equals(EVERDAWN)) startIfNeeded(player);
        if (player.level().dimension().location().equals(OTHERSIDE)) maybeGenerateCastle(player);
    }

    @SubscribeEvent
    public void onDimensionChange(PlayerEvent.PlayerChangedDimensionEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer player)) return;
        ResourceLocation destination = player.level().dimension().location();
        if (destination.equals(EVERDAWN)) {
            startIfNeeded(player);
            return;
        }

        DifficultyData d = data(player.getServer());
        if (!d.hasStarted() || !isProgressionDimension(destination)) return;

        if (d.registerDimension(destination.toString())) {
            player.getServer().getPlayerList().broadcastSystemMessage(Component.literal(String.format(
                    java.util.Locale.ROOT, "⚠ Nueva dimensión descubierta: %s | Los mobs hacen %.1fx de daño.",
                    destination, d.getMultiplier())).withStyle(ChatFormatting.GOLD), false);
        }
        if (destination.equals(OTHERSIDE)) maybeGenerateCastle(player);
    }

    private static void startIfNeeded(ServerPlayer player) {
        DifficultyData d = data(player.getServer());
        if (!d.hasStarted()) {
            d.startProgression();
            player.getServer().getPlayerList().broadcastSystemMessage(Component.literal(
                    "☠ ¡Se alcanzó Everdawn! Comienza la dificultad: los mobs hacen 2.5x de daño.")
                    .withStyle(ChatFormatting.DARK_RED, ChatFormatting.BOLD), false);
        }
    }

    private static void maybeGenerateCastle(ServerPlayer player) {
        DifficultyData d = data(player.getServer());
        if (!d.hasStarted() || d.isFinalCastleGenerated()) return;
        ServerLevel level = (ServerLevel) player.level();
        if (!level.dimension().location().equals(OTHERSIDE)) return;
        var center = FinalCastle.generate(level, player);
        d.setFinalCastleGenerated();
        player.getServer().getPlayerList().broadcastSystemMessage(Component.literal(
                "☠ EL SOBERANO DEL ABISMO ha despertado en un castillo de Deeper and Darker. ¡La batalla final ha comenzado!")
                .withStyle(ChatFormatting.DARK_PURPLE, ChatFormatting.BOLD), false);
        player.sendSystemMessage(Component.literal("Castillo generado cerca de X=" + center.getX()
                + ", Y=" + center.getY() + ", Z=" + center.getZ()).withStyle(ChatFormatting.GRAY));
    }

    private static boolean isProgressionDimension(ResourceLocation id) {
        // Solo cuentan los dos pasos de la ruta del servidor: Undergarden y Otherside.
        return id.getNamespace().equals("undergarden") || id.equals(OTHERSIDE);
    }

    @SubscribeEvent
    public void onLivingHurt(LivingHurtEvent event) {
        if (!(event.getEntity().level() instanceof ServerLevel level)) return;
        DifficultyData d = data(level.getServer());
        if (!d.isEnabled() || !d.hasStarted()) return;

        Entity attacker = event.getSource().getEntity();
        Entity direct = event.getSource().getDirectEntity();
        boolean mobDamage = attacker instanceof Mob;
        if (!mobDamage && direct instanceof Projectile projectile) mobDamage = projectile.getOwner() instanceof Mob;
        if (mobDamage) event.setAmount(event.getAmount() * (float) d.getMultiplier());
    }

    @SubscribeEvent
    public void onLivingTick(LivingEvent.LivingTickEvent event) {
        if (!(event.getEntity() instanceof Mob mob) || mob.level().isClientSide || !(mob.level() instanceof ServerLevel level)) return;
        if (mob.tickCount % 30 != 0) return;
        DifficultyData d = data(level.getServer());
        if (!d.isEnabled() || !d.hasStarted() || mob.getTarget() != null) return;
        level.players().stream().filter(p -> p.isAlive() && mob.distanceToSqr(p) <= 24.0D * 24.0D)
                .min(java.util.Comparator.comparingDouble(mob::distanceToSqr)).ifPresent(mob::setTarget);
    }
}
