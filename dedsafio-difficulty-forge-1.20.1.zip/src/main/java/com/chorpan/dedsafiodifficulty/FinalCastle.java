package com.chorpan.dedsafiodifficulty;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.monster.warden.Warden;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;

public final class FinalCastle {
    private FinalCastle() {}

    /** Builds one large arena near the first player who reaches the Otherside. */
    public static BlockPos generate(ServerLevel level, ServerPlayer player) {
        int cx = player.blockPosition().getX() + 48;
        int cz = player.blockPosition().getZ() + 48;
        int y = findFloor(level, cx, player.blockPosition().getY(), cz);
        BlockPos center = new BlockPos(cx, y, cz);

        // Clear the arena volume and lay a 49x49 reinforced floor.
        for (int dx = -24; dx <= 24; dx++) {
            for (int dz = -24; dz <= 24; dz++) {
                for (int dy = 1; dy <= 27; dy++) {
                    level.setBlock(center.offset(dx, dy, dz), Blocks.AIR.defaultBlockState(), 3);
                }
                level.setBlock(center.offset(dx, 0, dz), Blocks.DEEPSLATE_BRICKS.defaultBlockState(), 3);
            }
        }

        // Outer curtain walls, with a southern entrance.
        for (int h = 1; h <= 9; h++) {
            for (int i = -22; i <= 22; i++) {
                wallBlock(level, center.offset(i, h, -22));
                wallBlock(level, center.offset(i, h, 22));
                wallBlock(level, center.offset(-22, h, i));
                wallBlock(level, center.offset(22, h, i));
            }
        }
        // Open the gate and frame it with dark pillars.
        for (int h = 1; h <= 7; h++) {
            for (int x = -3; x <= 3; x++) level.setBlock(center.offset(x, h, 22), Blocks.AIR.defaultBlockState(), 3);
        }
        for (int h = 1; h <= 10; h++) {
            level.setBlock(center.offset(-4, h, 22), Blocks.CRYING_OBSIDIAN.defaultBlockState(), 3);
            level.setBlock(center.offset(4, h, 22), Blocks.CRYING_OBSIDIAN.defaultBlockState(), 3);
        }
        for (int x = -4; x <= 4; x++) level.setBlock(center.offset(x, 10, 22), Blocks.POLISHED_BLACKSTONE_BRICKS.defaultBlockState(), 3);

        // Four 9x9 towers, each with battlements and a glowing sculk crown.
        tower(level, center.offset(-20, 0, -20));
        tower(level, center.offset(20, 0, -20));
        tower(level, center.offset(-20, 0, 20));
        tower(level, center.offset(20, 0, 20));

        // Inner keep / throne hall.
        for (int h = 1; h <= 14; h++) {
            for (int x = -8; x <= 8; x++) {
                for (int z = -8; z <= 8; z++) {
                    if (Math.abs(x) == 8 || Math.abs(z) == 8) {
                        level.setBlock(center.offset(x, h, z), Blocks.POLISHED_DEEPSLATE.defaultBlockState(), 3);
                    }
                }
            }
        }
        // Leave a wide doorway on the south side of the keep.
        for (int h = 1; h <= 6; h++) for (int x = -2; x <= 2; x++) {
            level.setBlock(center.offset(x, h, 8), Blocks.AIR.defaultBlockState(), 3);
        }
        // Roof and parapets.
        for (int x = -9; x <= 9; x++) for (int z = -9; z <= 9; z++) {
            if (Math.abs(x) == 9 || Math.abs(z) == 9 || (x % 3 == 0 && z % 3 == 0)) {
                level.setBlock(center.offset(x, 14, z), Blocks.DEEPSLATE_TILES.defaultBlockState(), 3);
            }
        }
        // Raised boss dais.
        for (int h = 1; h <= 3; h++) {
            for (int x = -6; x <= 6; x++) for (int z = -6; z <= 6; z++) {
                if (Math.abs(x) + Math.abs(z) <= 8) {
                    level.setBlock(center.offset(x, h, z), Blocks.POLISHED_BLACKSTONE_BRICKS.defaultBlockState(), 3);
                }
            }
        }
        for (int x = -5; x <= 5; x += 2) {
            level.setBlock(center.offset(x, 4, -5), Blocks.SCULK_CATALYST.defaultBlockState(), 3);
            level.setBlock(center.offset(x, 4, 5), Blocks.SCULK_CATALYST.defaultBlockState(), 3);
        }
        for (int x : new int[]{-12, 12}) for (int z : new int[]{-12, 12}) {
            level.setBlock(center.offset(x, 5, z), Blocks.CRYING_OBSIDIAN.defaultBlockState(), 3);
            level.setBlock(center.offset(x, 6, z), Blocks.SOUL_LANTERN.defaultBlockState(), 3);
        }

        spawnBoss(level, center, player);
        return center;
    }

    private static int findFloor(ServerLevel level, int x, int startY, int z) {
        int max = Math.min(level.getMaxBuildHeight() - 30, startY + 8);
        for (int y = max; y >= Math.max(level.getMinBuildHeight() + 2, startY - 40); y--) {
            BlockPos floor = new BlockPos(x, y - 1, z);
            if (level.getBlockState(floor).isSolid() && level.getBlockState(new BlockPos(x, y, z)).isAir()) {
                return y;
            }
        }
        return Math.max(level.getMinBuildHeight() + 3, Math.min(startY, level.getMaxBuildHeight() - 30));
    }

    private static void wallBlock(ServerLevel level, BlockPos pos) {
        level.setBlock(pos, Blocks.DEEPSLATE_BRICKS.defaultBlockState(), 3);
        if (pos.getY() % 3 == 0) level.setBlock(pos, Blocks.CRACKED_DEEPSLATE_BRICKS.defaultBlockState(), 3);
    }

    private static void tower(ServerLevel level, BlockPos base) {
        for (int h = 1; h <= 25; h++) {
            for (int x = -4; x <= 4; x++) for (int z = -4; z <= 4; z++) {
                int edge = Math.max(Math.abs(x), Math.abs(z));
                if (edge == 4 || h == 1 || h == 25) {
                    level.setBlock(base.offset(x, h, z), Blocks.POLISHED_DEEPSLATE.defaultBlockState(), 3);
                }
            }
        }
        for (int x = -5; x <= 5; x++) for (int z = -5; z <= 5; z++) {
            if (Math.abs(x) == 5 || Math.abs(z) == 5) {
                level.setBlock(base.offset(x, 26, z), Blocks.DEEPSLATE_BRICKS.defaultBlockState(), 3);
            }
        }
        level.setBlock(base.offset(0, 24, 0), Blocks.SCULK_CATALYST.defaultBlockState(), 3);
        level.setBlock(base.offset(0, 25, 0), Blocks.SOUL_LANTERN.defaultBlockState(), 3);
    }

    private static void spawnBoss(ServerLevel level, BlockPos center, ServerPlayer firstPlayer) {
        Warden boss = EntityType.WARDEN.create(level);
        if (boss == null) return;
        double health = 900.0D;
        boss.getAttribute(Attributes.MAX_HEALTH).setBaseValue(health);
        boss.getAttribute(Attributes.ATTACK_DAMAGE).setBaseValue(32.0D);
        boss.getAttribute(Attributes.MOVEMENT_SPEED).setBaseValue(0.38D);
        boss.getAttribute(Attributes.ARMOR).setBaseValue(24.0D);
        boss.getAttribute(Attributes.KNOCKBACK_RESISTANCE).setBaseValue(1.0D);
        boss.getAttribute(Attributes.FOLLOW_RANGE).setBaseValue(96.0D);
        boss.setHealth((float) health);
        boss.setPersistenceRequired();
        boss.setCustomName(Component.literal("§4§lEL SOBERANO DEL ABISMO"));
        boss.setCustomNameVisible(true);
        boss.moveTo(center.getX() + 0.5D, center.getY() + 4.0D, center.getZ() + 0.5D, 0.0F, 0.0F);
        boss.setTarget(firstPlayer);
        level.addFreshEntity(boss);
    }
}
