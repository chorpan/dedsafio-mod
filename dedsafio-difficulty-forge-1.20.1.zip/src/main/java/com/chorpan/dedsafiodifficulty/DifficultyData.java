package com.chorpan.dedsafiodifficulty;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.StringTag;
import net.minecraft.world.level.saveddata.SavedData;

import java.util.HashSet;
import java.util.Set;

public class DifficultyData extends SavedData {
    public static final String DATA_NAME = "dedsafio_difficulty_data";
    private static final double BASE_MULTIPLIER = 2.5D;
    private static final double PER_DIMENSION = 0.2D;

    private boolean enabled = false;
    private boolean started = false;
    private boolean finalCastleGenerated = false;
    private final Set<String> discoveredDimensions = new HashSet<>();

    public DifficultyData() {}

    public static DifficultyData load(CompoundTag tag) {
        DifficultyData data = new DifficultyData();
        data.enabled = tag.getBoolean("Enabled");
        data.started = tag.getBoolean("Started");
        data.finalCastleGenerated = tag.getBoolean("FinalCastleGenerated");
        ListTag list = tag.getList("DiscoveredDimensions", 8);
        for (int i = 0; i < list.size(); i++) data.discoveredDimensions.add(list.getString(i));
        return data;
    }

    @Override
    public CompoundTag save(CompoundTag tag) {
        tag.putBoolean("Enabled", enabled);
        tag.putBoolean("Started", started);
        tag.putBoolean("FinalCastleGenerated", finalCastleGenerated);
        ListTag list = new ListTag();
        for (String dimension : discoveredDimensions) list.add(StringTag.valueOf(dimension));
        tag.put("DiscoveredDimensions", list);
        return tag;
    }

    public boolean isEnabled() { return enabled; }
    public void setEnabled(boolean value) { enabled = value; setDirty(); }
    public boolean hasStarted() { return started; }
    public void startProgression() { if (!started) { started = true; setDirty(); } }
    public boolean registerDimension(String id) {
        boolean added = discoveredDimensions.add(id);
        if (added) setDirty();
        return added;
    }
    public int getExtraDimensions() { return discoveredDimensions.size(); }
    public double getMultiplier() { return started ? BASE_MULTIPLIER + PER_DIMENSION * discoveredDimensions.size() : 1.0D; }
    public boolean isFinalCastleGenerated() { return finalCastleGenerated; }
    public void setFinalCastleGenerated() { finalCastleGenerated = true; setDirty(); }
}
