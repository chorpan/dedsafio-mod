# Dedsafio Difficulty — Forge 1.20.1

Mod independiente para el servidor. No necesita compilar contra los JAR de Blue Skies ni Deeper and Darker: detecta sus IDs de dimensión.

## Progresión

- `blue_skies:everbright`: no inicia la dificultad.
- `blue_skies:everdawn`: inicia en **2.5x**.
- Después de Everdawn, entrar por primera vez a una dimensión del namespace `undergarden` suma **+0.2x**. Entrar por primera vez a `deeperdarker:otherside` suma otros **+0.2x**.
- Cada paso suma una sola vez globalmente, aunque los jugadores vuelvan a visitarlo. Everbright y las dimensiones vanilla no suman.
- El orden queda Everbright → Everdawn → Undergarden → Deeper and Darker: 2.5x → 2.7x → 2.9x.

La dificultad queda guardada en los datos del mundo. Los comandos activan/desactivan el multiplicador para todos.

## Comandos (requieren OP nivel 2)

- `/dedsafio dificultad activar`
- `/dedsafio dificultad desactivar`
- `/dedsafio dificultad estado`

## Castillo final

Al llegar por primera vez a `deeperdarker:otherside` después de Everdawn, genera una fortaleza de deepslate de 49x49 con cuatro torres, murallas, torreón central, altar y un Warden jefe llamado **EL SOBERANO DEL ABISMO** (900 HP, 32 de daño base, 24 de armadura, 100% resistencia al retroceso). Se genera una sola vez por mundo, cerca del primer jugador que entra al Otherside.

## Alcance de hostilidad

El mod fuerza a los mobs cercanos a fijar como objetivo a jugadores, pero esto no puede dar una IA de ataque nueva a animales/entidades pasivas que no tengan objetivos de combate. Los mobs que ya poseen IA ofensiva podrán perseguir y atacar. El multiplicador sí se aplica al daño de mobs y proyectiles propiedad de mobs.

## Build

GitHub Actions compila con Java 17 y Gradle 8.8. JAR en `build/libs/`.
