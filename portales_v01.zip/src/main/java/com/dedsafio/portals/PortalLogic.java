package com.dedsafio.portals;

import com.dedsafio.portals.PortalesData.Punto;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.server.ServerLifecycleHooks;

/** Validacion, requisitos, animacion y viaje. Solo se viaja por aca (o por un admin si esta habilitado). */
@Mod.EventBusSubscriber(modid = PortalesMod.MODID)
public class PortalLogic {
    private static final int DURACION = 60;
    private static final Set<UUID> BYPASS = new HashSet<>();
    private static final List<Animacion> ANIMACIONES = new ArrayList<>();

    private static class Animacion {
        final UUID jugador;
        final ResourceKey<Level> dim;
        final BlockPos nucleo;
        final PortalTipo tipo;
        final boolean adelante;
        int ticks = 0;

        Animacion(UUID jugador, ResourceKey<Level> dim, BlockPos nucleo, PortalTipo tipo, boolean adelante) {
            this.jugador = jugador;
            this.dim = dim;
            this.nucleo = nucleo;
            this.tipo = tipo;
            this.adelante = adelante;
        }
    }

    public static boolean enBypass(UUID u) { return BYPASS.contains(u); }

    private static void msg(ServerPlayer p, String texto) {
        p.displayClientMessage(Component.literal(texto), true);
    }

    /** Marco 5x5 del tipo correcto, interior libre y espacio sobre el nucleo. null = valido. */
    public static String validar(ServerLevel lvl, BlockPos nucleo, PortalTipo tipo) {
        Block marco = Registro.MARCO.get(tipo).get();
        int mal = 0;
        for (int dx = -2; dx <= 2; dx++) {
            for (int dz = -2; dz <= 2; dz++) {
                int r = Math.max(Math.abs(dx), Math.abs(dz));
                if (r == 0) continue;
                BlockState s = lvl.getBlockState(nucleo.offset(dx, 0, dz));
                if (r == 2) {
                    if (s.getBlock() != marco) mal++;
                } else if (!s.isAir()) {
                    mal++;
                }
            }
        }
        if (!lvl.getBlockState(nucleo.above()).isAir()) mal++;
        if (mal > 0) return "Estructura invalida (" + mal + " bloque/s mal): marco 5x5 del mismo tipo, nucleo al centro e interior libre";
        return null;
    }

    private static List<String> faltantes(ServerPlayer p, PortalTipo tipo, PortalesData d) {
        List<String> faltan = new ArrayList<>();
        for (String id : Config.REQUISITOS.get(tipo.numero - 1).get()) {
            ResourceLocation rl = ResourceLocation.tryParse(id);
            if (rl == null || !ForgeRegistries.ENTITY_TYPES.containsKey(rl)) continue; // IDs inexistentes no bloquean
            if (!d.derroto(p.getUUID(), id)) {
                EntityType<?> et = ForgeRegistries.ENTITY_TYPES.getValue(rl);
                faltan.add(et == null ? id : et.getDescription().getString());
            }
        }
        return faltan;
    }

    public static void usar(ServerPlayer p, ServerLevel lvl, BlockPos nucleo, PortalTipo tipo) {
        for (Animacion a : ANIMACIONES) if (a.jugador.equals(p.getUUID())) return;
        String falla = validar(lvl, nucleo, tipo);
        if (falla != null) { msg(p, falla); return; }

        Etapa actual = Etapa.de(lvl, nucleo);
        boolean adelante;
        if (actual == tipo.desde) adelante = true;
        else if (actual == tipo.hasta) adelante = false;
        else { msg(p, "Este portal no conecta con esta zona"); return; }

        PortalesData d = PortalesData.get(p.server);
        int etapa = d.etapaMax(p.getUUID());
        if (adelante) {
            if (etapa < tipo.desde.ordinal()) { msg(p, "Todavia no llegaste a esta etapa por el camino correcto"); return; }
            List<String> faltan = faltantes(p, tipo, d);
            if (!faltan.isEmpty()) { msg(p, "Te falta derrotar: " + String.join(", ", faltan)); return; }
        } else if (etapa < tipo.hasta.ordinal()) {
            msg(p, "Todavia no desbloqueaste esta conexion");
            return;
        }

        BlockState st = lvl.getBlockState(nucleo);
        if (!st.getValue(NucleoPortalBlock.ACTIVO)) lvl.setBlock(nucleo, st.setValue(NucleoPortalBlock.ACTIVO, true), 3);
        lvl.playSound(null, nucleo, SoundEvents.END_PORTAL_SPAWN, SoundSource.BLOCKS, 1.0F, 1.0F);
        ANIMACIONES.add(new Animacion(p.getUUID(), lvl.dimension(), nucleo, tipo, adelante));
        msg(p, "El portal se activa... no te muevas");
    }

    @SubscribeEvent
    public static void tick(TickEvent.ServerTickEvent e) {
        if (e.phase != TickEvent.Phase.END || ANIMACIONES.isEmpty()) return;
        MinecraftServer server = ServerLifecycleHooks.getCurrentServer();
        if (server == null) return;
        Iterator<Animacion> it = ANIMACIONES.iterator();
        while (it.hasNext()) {
            Animacion a = it.next();
            ServerPlayer p = server.getPlayerList().getPlayer(a.jugador);
            ServerLevel lvl = server.getLevel(a.dim);
            if (p == null || lvl == null || !p.isAlive() || p.serverLevel() != lvl
                    || p.distanceToSqr(a.nucleo.getX() + 0.5, a.nucleo.getY(), a.nucleo.getZ() + 0.5) > 36.0) {
                if (p != null) msg(p, "Portal cancelado");
                it.remove();
                continue;
            }
            a.ticks++;
            if (a.ticks % 2 == 0) efectos(lvl, a);
            if (a.ticks >= DURACION) {
                it.remove();
                viajar(server, p, lvl, a);
            }
        }
    }

    private static void efectos(ServerLevel lvl, Animacion a) {
        double cx = a.nucleo.getX() + 0.5, cz = a.nucleo.getZ() + 0.5;
        double y = a.nucleo.getY() + 1.0 + (a.ticks / (double) DURACION) * 2.5;
        for (int i = 0; i < 8; i++) {
            double ang = a.ticks * 0.3 + i * Math.PI / 4.0;
            lvl.sendParticles(ParticleTypes.PORTAL, cx + Math.cos(ang) * 1.8, y, cz + Math.sin(ang) * 1.8, 2, 0.1, 0.1, 0.1, 0.05);
        }
        lvl.sendParticles(ParticleTypes.ENCHANT, cx, a.nucleo.getY() + 1.5, cz, 6, 0.6, 0.6, 0.6, 0.5);
        if (a.ticks % 20 == 0) lvl.playSound(null, a.nucleo, SoundEvents.PORTAL_AMBIENT, SoundSource.BLOCKS, 1.0F, 1.0F);
    }

    private static void viajar(MinecraftServer server, ServerPlayer p, ServerLevel lvl, Animacion a) {
        String falla = validar(lvl, a.nucleo, a.tipo);
        if (falla != null) { msg(p, falla); return; }
        Punto destino = a.adelante ? PortalMundo.destinoAdelante(server, a.tipo) : PortalMundo.destinoAtras(server, p, a.tipo);
        ServerLevel dl = destino == null ? null : server.getLevel(destino.dim());
        if (dl == null) { msg(p, "Esa dimension no esta disponible (falta el mod de esa zona)"); return; }
        PortalesData d = PortalesData.get(server);
        if (a.adelante) {
            d.guardarOrigen(p.getUUID(), a.tipo, a.dim, a.nucleo);
            d.subirEtapa(p.getUUID(), a.tipo.hasta.ordinal());
        }
        BYPASS.add(p.getUUID());
        try {
            p.teleportTo(dl, destino.pos().getX() + 0.5, destino.pos().getY() + 1.0, destino.pos().getZ() + 0.5, p.getYRot(), p.getXRot());
        } finally {
            BYPASS.remove(p.getUUID());
        }
        p.playNotifySound(SoundEvents.PORTAL_TRAVEL, SoundSource.PLAYERS, 0.8F, 1.0F);
        Etapa nueva = a.adelante ? a.tipo.hasta : a.tipo.desde;
        msg(p, "Llegaste a: " + nueva.nombre);
    }
}
