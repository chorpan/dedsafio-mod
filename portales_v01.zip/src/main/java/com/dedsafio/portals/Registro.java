package com.dedsafio.portals;

import java.util.EnumMap;
import java.util.Map;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Block;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class Registro {
    public static final DeferredRegister<Block> BLOCKS = DeferredRegister.create(ForgeRegistries.BLOCKS, PortalesMod.MODID);
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, PortalesMod.MODID);
    public static final DeferredRegister<CreativeModeTab> TABS = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, PortalesMod.MODID);

    public static final Map<PortalTipo, RegistryObject<Block>> MARCO = new EnumMap<>(PortalTipo.class);
    public static final Map<PortalTipo, RegistryObject<Block>> NUCLEO = new EnumMap<>(PortalTipo.class);

    static {
        for (PortalTipo t : PortalTipo.values()) {
            RegistryObject<Block> marco = BLOCKS.register("marco_" + t.numero, () -> new MarcoPortalBlock(t));
            RegistryObject<Block> nucleo = BLOCKS.register("nucleo_" + t.numero, () -> new NucleoPortalBlock(t));
            MARCO.put(t, marco);
            NUCLEO.put(t, nucleo);
            ITEMS.register("marco_" + t.numero, () -> new BlockItem(marco.get(), new Item.Properties()));
            ITEMS.register("nucleo_" + t.numero, () -> new BlockItem(nucleo.get(), new Item.Properties()));
        }
    }

    public static final RegistryObject<CreativeModeTab> TAB = TABS.register("portales", () -> CreativeModeTab.builder()
            .title(Component.translatable("itemGroup.dedsafio_portals"))
            .icon(() -> new ItemStack(MARCO.get(PortalTipo.P1).get()))
            .displayItems((params, out) -> ITEMS.getEntries().forEach(i -> out.accept(i.get())))
            .build());
}
