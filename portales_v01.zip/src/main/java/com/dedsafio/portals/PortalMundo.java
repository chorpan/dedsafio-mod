package com.dedsafio.portals;

import com.dedsafio.portals.PortalesData.Punto;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraftforge.registries.ForgeRegistries;

/** Construccion de portales de llegada y busqueda de destinos. */
public final class PortalMundo {
    private PortalMundo() {}

    public static ServerLevel nivel(MinecraftServer s, Etapa e) {
        return s.getLevel(Etapa.dimension(e));
    }

    /** Destino de ida: el portal "de llegada" de la etapa siguiente (se crea la primera vez). */
    public static Punto destinoAdelante(MinecraftServer s, PortalTipo t) {
        ServerLevel lvl = nivel(s, t.hasta);
        if (lvl == null) return null;
        PortalesData d = PortalesData.get(s);
        String clave = "adelante" + t.numero;
        Punto g = d.destino(clave);
        if (valido(s, g, t)) return g;
        int x = 0, z = 0;
        if (t.hasta == Etapa.FINAL) { x = Config.FINAL_X.get(); z = Config.FINAL_Z.get(); }
        BlockPos n = colocar(lvl, x, z, t);
        if (t.hasta == Etapa.FINAL) arenaFinal(lvl, n);
        Punto p = new Punto(lvl.dimension(), n);
        d.guardarDestino(clave, p);
        return p;
    }

    /** Destino de vuelta: el portal que ese jugador uso para salir; si ya no existe, uno de respaldo. */
    public static Punto destinoAtras(MinecraftServer s, ServerPlayer jugador, PortalTipo t) {
        PortalesData d = PortalesData.get(s);
        Punto o = d.origen(jugador.getUUID(), t);
        if (valido(s, o, t)) return o;
        ServerLevel lvl = nivel(s, t.desde);
        if (lvl == null) return null;
        String clave = "atras" + t.numero;
        Punto g = d.destino(clave);
        if (valido(s, g, t)) return g;
        int x = 0, z = 0;
        if (t.desde == Etapa.OVERWORLD) {
            BlockPos sp = lvl.getSharedSpawnPos();
            x = sp.getX();
            z = sp.getZ();
        } else if (t.desde == Etapa.FINAL) {
            x = Config.FINAL_X.get();
            z = Config.FINAL_Z.get();
        }
        BlockPos n = colocar(lvl, x, z, t);
        Punto p = new Punto(lvl.dimension(), n);
        d.guardarDestino(clave, p);
        return p;
    }

    private static boolean valido(MinecraftServer s, Punto p, PortalTipo t) {
        if (p == null) return false;
        ServerLevel l = s.getLevel(p.dim());
        return l != null && l.getBlockState(p.pos()).getBlock() == Registro.NUCLEO.get(t).get();
    }

    private static BlockPos colocar(ServerLevel lvl, int x, int z, PortalTipo t) {
        BlockPos n = new BlockPos(x, buscarY(lvl, x, z), z);
        construir(lvl, n, t);
        return n;
    }

    private static boolean libre(ServerLevel lvl, int x, int y, int z) {
        BlockPos abajo = new BlockPos(x, y - 1, z);
        if (!lvl.getBlockState(abajo).isFaceSturdy(lvl, abajo, Direction.UP) || !lvl.getFluidState(abajo).isEmpty()) return false;
        for (int i = 0; i <= 4; i++) {
            if (!lvl.getBlockState(new BlockPos(x, y + i, z)).isAir()) return false;
        }
        return true;
    }

    private static int buscarY(ServerLevel lvl, int x, int z) {
        int min = lvl.getMinBuildHeight() + 3;
        int top = lvl.getMinBuildHeight() + Math.min(lvl.getHeight(), lvl.dimensionType().logicalHeight()) - 8;
        if (lvl.dimensionType().hasCeiling()) {
            for (int y = min + 8; y <= top; y++) if (libre(lvl, x, y, z)) return y;
        } else {
            for (int y = top; y >= min; y--) if (libre(lvl, x, y, z)) return y;
        }
        return Math.max(min, Math.min(top, 64));
    }

    /** Marco de 5x5 con el nucleo (activo) en el centro; limpia el interior y apoya el piso. */
    public static void construir(ServerLevel lvl, BlockPos n, PortalTipo t) {
        BlockState marco = Registro.MARCO.get(t).get().defaultBlockState();
        BlockState nucleo = Registro.NUCLEO.get(t).get().defaultBlockState().setValue(NucleoPortalBlock.ACTIVO, true);
        BlockState piso = Blocks.POLISHED_BLACKSTONE_BRICKS.defaultBlockState();
        BlockState aire = Blocks.AIR.defaultBlockState();
        for (int dx = -3; dx <= 3; dx++) {
            for (int dz = -3; dz <= 3; dz++) {
                BlockPos base = n.offset(dx, -1, dz);
                if (!lvl.getBlockState(base).isFaceSturdy(lvl, base, Direction.UP)) lvl.setBlock(base, piso, 3);
                int r = Math.max(Math.abs(dx), Math.abs(dz));
                if (r <= 2) {
                    BlockState st = r == 2 ? marco : (dx == 0 && dz == 0 ? nucleo : aire);
                    lvl.setBlock(n.offset(dx, 0, dz), st, 3);
                    for (int dy = 1; dy <= 4; dy++) lvl.setBlock(n.offset(dx, dy, dz), aire, 3);
                }
            }
        }
    }

    /** Plataforma de desafio alrededor del portal de llegada de la zona final. */
    private static void arenaFinal(ServerLevel lvl, BlockPos c) {
        BlockState piso = Blocks.BLACKSTONE.defaultBlockState();
        BlockState borde = Blocks.POLISHED_BLACKSTONE_BRICKS.defaultBlockState();
        BlockState aire = Blocks.AIR.defaultBlockState();
        int radio = 20;
        for (int dx = -radio; dx <= radio; dx++) {
            for (int dz = -radio; dz <= radio; dz++) {
                double dist = Math.sqrt(dx * dx + dz * dz);
                if (dist > radio + 0.5 || (Math.abs(dx) <= 3 && Math.abs(dz) <= 3)) continue;
                lvl.setBlock(c.offset(dx, -1, dz), dist > radio - 2 ? borde : piso, 3);
                for (int dy = 0; dy <= 10; dy++) lvl.setBlock(c.offset(dx, dy, dz), aire, 3);
            }
        }
        for (int i = 0; i < 8; i++) {
            double ang = i * Math.PI / 4.0;
            int px = (int) Math.round(Math.cos(ang) * (radio - 3));
            int pz = (int) Math.round(Math.sin(ang) * (radio - 3));
            for (int dy = 0; dy <= 7; dy++) lvl.setBlock(c.offset(px, dy, pz), borde, 3);
            lvl.setBlock(c.offset(px, 8, pz), Blocks.SHROOMLIGHT.defaultBlockState(), 3);
        }
        int k = 0;
        for (String id : Config.JEFES_FINAL.get()) {
            ResourceLocation rl = ResourceLocation.tryParse(id);
            if (rl == null || !ForgeRegistries.ENTITY_TYPES.containsKey(rl)) continue;
            EntityType<?> tipo = ForgeRegistries.ENTITY_TYPES.getValue(rl);
            Entity e = tipo == null ? null : tipo.create(lvl);
            if (e == null) continue;
            e.moveTo(c.getX() + 0.5 + 10, c.getY(), c.getZ() + 0.5 + (k++ * 4 - 4), 0.0F, 0.0F);
            lvl.addFreshEntity(e);
        }
    }
}
