package com.dedsafio.portals;

import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.RandomSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.phys.BlockHitResult;

/** Bloque central del portal: click derecho para activarlo. */
public class NucleoPortalBlock extends Block {
    public static final BooleanProperty ACTIVO = BooleanProperty.create("activo");
    public final PortalTipo tipo;

    public NucleoPortalBlock(PortalTipo tipo) {
        super(BlockBehaviour.Properties.of().strength(5.0F, 12.0F).sound(SoundType.AMETHYST)
                .lightLevel(s -> s.getValue(ACTIVO) ? 13 : 4));
        this.tipo = tipo;
        this.registerDefaultState(this.stateDefinition.any().setValue(ACTIVO, false));
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(ACTIVO);
    }

    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        if (level.isClientSide()) return InteractionResult.SUCCESS;
        if (player instanceof ServerPlayer sp && level instanceof ServerLevel sl) {
            PortalLogic.usar(sp, sl, pos, tipo);
        }
        return InteractionResult.CONSUME;
    }

    @Override
    public void animateTick(BlockState state, Level level, BlockPos pos, RandomSource random) {
        if (!state.getValue(ACTIVO)) return;
        for (int i = 0; i < 3; i++) {
            level.addParticle(ParticleTypes.PORTAL,
                    pos.getX() + 0.5 + (random.nextDouble() - 0.5) * 2.0,
                    pos.getY() + 1.0 + random.nextDouble() * 2.0,
                    pos.getZ() + 0.5 + (random.nextDouble() - 0.5) * 2.0,
                    0.0, 0.1, 0.0);
        }
    }
}
