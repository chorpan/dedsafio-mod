package com.dedsafio.portals;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;

public class MarcoPortalBlock extends Block {
    public final PortalTipo tipo;

    public MarcoPortalBlock(PortalTipo tipo) {
        super(BlockBehaviour.Properties.of().strength(5.0F, 12.0F).sound(SoundType.STONE).lightLevel(s -> 4));
        this.tipo = tipo;
    }
}
