package com.dedsafio.portals;

import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.event.entity.EntityTravelToDimensionEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.registries.ForgeRegistries;

@Mod.EventBusSubscriber(modid = PortalesMod.MODID)
public class PortalEvents {

    /**
     * Compatibilidad con los portales originales: sin editar esos mods, se cancela cualquier viaje
     * que entre o salga de las etapas restringidas salvo los hechos por nuestros portales.
     */
    @SubscribeEvent
    public static void alViajar(EntityTravelToDimensionEvent e) {
        if (!(e.getEntity() instanceof ServerPlayer p)) return;
        if (PortalLogic.enBypass(p.getUUID())) return;
        if (Config.ADMIN_LIBRE.get() && p.hasPermissions(4)) return;
        Etapa desde = Etapa.de(p.serverLevel(), p.blockPosition());
        Etapa hacia = Etapa.deDimension(e.getDimension());
        boolean sale = desde != null && desde.ordinal() >= Etapa.BLUE_SKIES.ordinal() && desde != hacia;
        boolean entra = hacia != null && hacia.gestionada() && desde != hacia;
        if (sale || entra) {
            e.setCanceled(true);
            p.displayClientMessage(Component.literal("Solo se viaja entre estas dimensiones con los portales del Dedsafio, en orden"), true);
        }
    }

    @SubscribeEvent
    public static void alMatar(LivingDeathEvent e) {
        if (!(e.getSource().getEntity() instanceof ServerPlayer p)) return;
        ResourceLocation id = ForgeRegistries.ENTITY_TYPES.getKey(e.getEntity().getType());
        if (id == null) return;
        String s = id.toString();
        for (var lista : Config.REQUISITOS) {
            if (lista.get().contains(s)) {
                if (PortalesData.get(p.server).registrarKill(p.getUUID(), s)) {
                    p.displayClientMessage(Component.literal("Derrotaste a: " + e.getEntity().getName().getString()), true);
                }
                break;
            }
        }
    }
}
