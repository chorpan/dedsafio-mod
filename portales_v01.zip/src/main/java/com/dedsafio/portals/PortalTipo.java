package com.dedsafio.portals;

/** Cada tipo de portal conecta dos etapas consecutivas. */
public enum PortalTipo {
    P1(1, Etapa.OVERWORLD, Etapa.BLUE_SKIES),
    P2(2, Etapa.BLUE_SKIES, Etapa.UNDERGARDEN),
    P3(3, Etapa.UNDERGARDEN, Etapa.OTHERSIDE),
    P4(4, Etapa.OTHERSIDE, Etapa.FINAL);

    public final int numero;
    public final Etapa desde;
    public final Etapa hasta;

    PortalTipo(int numero, Etapa desde, Etapa hasta) {
        this.numero = numero;
        this.desde = desde;
        this.hasta = hasta;
    }
}
