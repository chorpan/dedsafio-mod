package com.dedsafio.portals;

import java.util.ArrayList;
import java.util.List;
import net.minecraftforge.common.ForgeConfigSpec;

public class Config {
    public static final ForgeConfigSpec SPEC;
    public static final ForgeConfigSpec.IntValue FINAL_X;
    public static final ForgeConfigSpec.IntValue FINAL_Z;
    public static final ForgeConfigSpec.BooleanValue ADMIN_LIBRE;
    public static final ForgeConfigSpec.ConfigValue<List<? extends String>> JEFES_FINAL;
    /** Indice 0 = portal 1 ... indice 3 = portal 4. Entidades que cada jugador debe haber matado para ir ADELANTE. */
    public static final List<ForgeConfigSpec.ConfigValue<List<? extends String>>> REQUISITOS = new ArrayList<>();

    static {
        ForgeConfigSpec.Builder b = new ForgeConfigSpec.Builder();
        FINAL_X = b.comment("Coordenada X (Overworld) del centro de la zona final").defineInRange("zona_final_x", 1000000, -29000000, 29000000);
        FINAL_Z = b.comment("Coordenada Z (Overworld) del centro de la zona final").defineInRange("zona_final_z", 1000000, -29000000, 29000000);
        ADMIN_LIBRE = b.comment("Si es true, los operadores nivel 4 pueden saltarse las reglas de viaje (solo para pruebas)")
                .define("admin_viaja_libre", false);
        JEFES_FINAL = b.comment("IDs de entidades que aparecen al crear la zona final (ej: cataclysm:ender_golem). Vacio = ninguna.")
                .defineListAllowEmpty("jefes_zona_final", List.<String>of(), o -> o instanceof String);
        b.comment("Requisitos para ir ADELANTE: entidades que el jugador debe haber matado. IDs que no existan se ignoran.");
        REQUISITOS.add(b.defineListAllowEmpty("requisitos_portal_1", List.<String>of(), o -> o instanceof String));
        REQUISITOS.add(b.defineListAllowEmpty("requisitos_portal_2",
                List.of("blue_skies:alchemist", "blue_skies:arachnarch", "blue_skies:summoner", "blue_skies:starlit_crusher"), o -> o instanceof String));
        REQUISITOS.add(b.defineListAllowEmpty("requisitos_portal_3", List.<String>of(), o -> o instanceof String));
        REQUISITOS.add(b.defineListAllowEmpty("requisitos_portal_4",
                List.of("deeperdarker:stalker", "minecraft:warden"), o -> o instanceof String));
        SPEC = b.build();
    }
}
