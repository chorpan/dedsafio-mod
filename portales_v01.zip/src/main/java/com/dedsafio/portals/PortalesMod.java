package com.dedsafio.portals;

import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.config.ModConfig;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

@Mod(PortalesMod.MODID)
public class PortalesMod {
    public static final String MODID = "dedsafio_portals";

    public PortalesMod() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        Registro.BLOCKS.register(bus);
        Registro.ITEMS.register(bus);
        Registro.TABS.register(bus);
        ModLoadingContext.get().registerConfig(ModConfig.Type.SERVER, Config.SPEC);
    }
}
