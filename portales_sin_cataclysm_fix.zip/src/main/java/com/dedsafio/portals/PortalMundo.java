package com.dedsafio.portals;

import com.dedsafio.portals.PortalesData.Punto;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.Level;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraftforge.registries.ForgeRegistries;

/** Construccion de portales de llegada y busqueda de destinos. */
public final class PortalMundo {
    private PortalMundo() {}

    public static ServerLevel nivel(MinecraftServer s, Etapa e) {
        return s.getLevel(Etapa.dimension(e));
    }

    /** Destino de ida: el portal "de llegada" de la etapa siguiente (se crea la primera vez). */
    public static Punto destinoAdelante(MinecraftServer s, PortalTipo t) {
        // El ultimo portal (Otherside -> Overworld) devuelve directamente al spawn del mundo.
        if (t.hasta == Etapa.OVERWORLD) {
            ServerLevel overworld = s.overworld();
            BlockPos spawn = overworld.getSharedSpawnPos();
            return new Punto(Level.OVERWORLD, spawn);
        }

        ServerLevel lvl = nivel(s, t.hasta);
        if (lvl == null) return null;
        PortalesData d = PortalesData.get(s);
        String clave = "adelante" + t.numero;
        Punto g = d.destino(clave);
        if (valido(s, g, t)) return g;
        BlockPos n = colocar(lvl, 0, 0, t);
        Punto p = new Punto(lvl.dimension(), n);
        d.guardarDestino(clave, p);
        return p;
    }

    /** Destino de vuelta: el portal que ese jugador uso para salir; si ya no existe, uno de respaldo. */
    public static Punto destinoAtras(MinecraftServer s, ServerPlayer jugador, PortalTipo t) {
        PortalesData d = PortalesData.get(s);
        Punto o = d.origen(jugador.getUUID(), t);
        if (valido(s, o, t)) return o;
        ServerLevel lvl = nivel(s, t.desde);
        if (lvl == null) return null;
        String clave = "atras" + t.numero;
        Punto g = d.destino(clave);
        if (valido(s, g, t)) return g;
        int x = 0, z = 0;
        if (t.desde == Etapa.OVERWORLD) {
            BlockPos sp = lvl.getSharedSpawnPos();
            x = sp.getX();
            z = sp.getZ();
        }
        BlockPos n = colocar(lvl, x, z, t);
        Punto p = new Punto(lvl.dimension(), n);
        d.guardarDestino(clave, p);
        return p;
    }

    private static boolean valido(MinecraftServer s, Punto p, PortalTipo t) {
        if (p == null) return false;
        ServerLevel l = s.getLevel(p.dim());
        return l != null && l.getBlockState(p.pos()).getBlock() == Registro.NUCLEO.get(t).get();
    }

    private static BlockPos colocar(ServerLevel lvl, int x, int z, PortalTipo t) {
        BlockPos n = new BlockPos(x, buscarY(lvl, x, z), z);
        construir(lvl, n, t);
        return n;
    }

    private static boolean libre(ServerLevel lvl, int x, int y, int z) {
        BlockPos abajo = new BlockPos(x, y - 1, z);
        if (!lvl.getBlockState(abajo).isFaceSturdy(lvl, abajo, Direction.UP) || !lvl.getFluidState(abajo).isEmpty()) return false;
        for (int i = 0; i <= 4; i++) {
            if (!lvl.getBlockState(new BlockPos(x, y + i, z)).isAir()) return false;
        }
        return true;
    }

    private static int buscarY(ServerLevel lvl, int x, int z) {
        int min = lvl.getMinBuildHeight() + 3;
        int top = lvl.getMinBuildHeight() + Math.min(lvl.getHeight(), lvl.dimensionType().logicalHeight()) - 8;
        if (lvl.dimensionType().hasCeiling()) {
            for (int y = min + 8; y <= top; y++) if (libre(lvl, x, y, z)) return y;
        } else {
            for (int y = top; y >= min; y--) if (libre(lvl, x, y, z)) return y;
        }
        return Math.max(min, Math.min(top, 64));
    }

    /** Marco de 5x5 con el nucleo (activo) en el centro; limpia el interior y apoya el piso. */
    public static void construir(ServerLevel lvl, BlockPos n, PortalTipo t) {
        BlockState marco = Registro.MARCO.get(t).get().defaultBlockState();
        BlockState nucleo = Registro.NUCLEO.get(t).get().defaultBlockState().setValue(NucleoPortalBlock.ACTIVO, true);
        BlockState piso = Blocks.POLISHED_BLACKSTONE_BRICKS.defaultBlockState();
        BlockState aire = Blocks.AIR.defaultBlockState();
        for (int dx = -3; dx <= 3; dx++) {
            for (int dz = -3; dz <= 3; dz++) {
                BlockPos base = n.offset(dx, -1, dz);
                if (!lvl.getBlockState(base).isFaceSturdy(lvl, base, Direction.UP)) lvl.setBlock(base, piso, 3);
                int r = Math.max(Math.abs(dx), Math.abs(dz));
                if (r <= 2) {
                    BlockState st = r == 2 ? marco : (dx == 0 && dz == 0 ? nucleo : aire);
                    lvl.setBlock(n.offset(dx, 0, dz), st, 3);
                    for (int dy = 1; dy <= 4; dy++) lvl.setBlock(n.offset(dx, dy, dz), aire, 3);
                }
            }
        }
    }

}
