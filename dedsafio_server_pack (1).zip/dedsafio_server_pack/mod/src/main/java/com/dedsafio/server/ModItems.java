package com.dedsafio.server;

import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModItems {
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, DedsafioServer.MODID);
    public static final DeferredRegister<CreativeModeTab> TABS = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, DedsafioServer.MODID);

    public static final RegistryObject<Item> DEDITA_AZUL = ITEMS.register("dedita_azul", () -> new Item(new Item.Properties()));
    public static final RegistryObject<Item> DEDITA_ROJA = ITEMS.register("dedita_roja", () -> new Item(new Item.Properties()));
    public static final RegistryObject<Item> DEDITA_VERDE = ITEMS.register("dedita_verde", () -> new Item(new Item.Properties()));
    public static final RegistryObject<Item> PALITO_MAGICO = ITEMS.register("palito_magico", () -> new PalitoMagicoItem(new Item.Properties().stacksTo(1)));

    public static final RegistryObject<CreativeModeTab> TAB = TABS.register("dedsafio", () -> CreativeModeTab.builder()
            .title(Component.translatable("itemGroup.dedsafio_server"))
            .icon(() -> DEDITA_AZUL.get().getDefaultInstance())
            .displayItems((params, out) -> ITEMS.getEntries().forEach(i -> out.accept(i.get())))
            .build());
}
