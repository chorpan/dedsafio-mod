package com.dedsafio.server;

import java.util.List;
import net.minecraftforge.common.ForgeConfigSpec;

public class Config {
    public static final ForgeConfigSpec SPEC;
    public static final ForgeConfigSpec.BooleanValue ELIMINACION;
    public static final ForgeConfigSpec.ConfigValue<List<? extends String>> RULETA;

    static {
        ForgeConfigSpec.Builder b = new ForgeConfigSpec.Builder();
        ELIMINACION = b.comment("Si es true, quien muere queda eliminado (espectador) hasta que un admin use /dedsafio revive.")
                .define("eliminacion_al_morir", true);
        RULETA = b.comment("Opciones de /dedsafio ruleta. Formato: 'Texto que ven todos' o 'Texto => comando' (el comando se ejecuta como consola, sin la barra).")
                .defineListAllowEmpty("ruleta_opciones", List.of(
                        "Tormenta electrica => weather thunder 6000",
                        "Noche eterna => time set midnight",
                        "Regalo: una dedita azul para todos => give @a dedsafio_server:dedita_azul 1",
                        "Todos lentos por un minuto => effect give @a minecraft:slowness 60 1",
                        "Dificultad DIFICIL => dedsafio dificultad dificil",
                        "Nada... esta vez te salvaste"), o -> o instanceof String);
        SPEC = b.build();
    }
}
