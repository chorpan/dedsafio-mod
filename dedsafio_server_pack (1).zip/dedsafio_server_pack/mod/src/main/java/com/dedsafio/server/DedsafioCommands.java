package com.dedsafio.server;

import com.mojang.authlib.GameProfile;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import net.minecraft.ChatFormatting;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.SharedSuggestionProvider;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.players.GameProfileCache;
import net.minecraft.world.Difficulty;
import net.minecraft.world.level.GameType;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = DedsafioServer.MODID)
public class DedsafioCommands {
    private static final String[] MODOS = {"survival", "creative", "adventure", "spectator"};
    private static final String[] NIVELES = {"pacifico", "facil", "normal", "dificil"};

    @SubscribeEvent
    public static void registrar(RegisterCommandsEvent e) {
        CommandDispatcher<CommandSourceStack> d = e.getDispatcher();
        d.register(Commands.literal("dedsafio").requires(s -> s.hasPermission(2))
                .then(Commands.literal("revive")
                        .then(Commands.argument("jugador", EntityArgument.player())
                                .executes(c -> revivir(c, GameType.SURVIVAL))
                                .then(Commands.argument("modo", StringArgumentType.word())
                                        .suggests((c, b) -> SharedSuggestionProvider.suggest(MODOS, b))
                                        .executes(c -> {
                                            GameType m = GameType.byName(StringArgumentType.getString(c, "modo"), null);
                                            if (m == null) { c.getSource().sendFailure(Component.literal("Modo invalido")); return 0; }
                                            return revivir(c, m);
                                        }))))
                .then(Commands.literal("eliminar")
                        .then(Commands.argument("jugador", EntityArgument.player()).executes(DedsafioCommands::eliminar)))
                .then(Commands.literal("eliminados").executes(DedsafioCommands::listar))
                .then(Commands.literal("dificultad")
                        .then(Commands.argument("nivel", StringArgumentType.word())
                                .suggests((c, b) -> SharedSuggestionProvider.suggest(NIVELES, b))
                                .executes(DedsafioCommands::dificultad)))
                .then(Commands.literal("ruleta").executes(DedsafioCommands::ruleta))
                .then(Commands.literal("anuncio")
                        .then(Commands.argument("texto", StringArgumentType.greedyString()).executes(c -> {
                            Anuncios.titulo(c.getSource().getServer(), Component.literal("DEDSAFIO").withStyle(ChatFormatting.GOLD),
                                    Component.literal(StringArgumentType.getString(c, "texto")));
                            return 1;
                        }))));
    }

    private static int revivir(CommandContext<CommandSourceStack> c, GameType modo) throws com.mojang.brigadier.exceptions.CommandSyntaxException {
        ServerPlayer p = EntityArgument.getPlayer(c, "jugador");
        MinecraftServer server = c.getSource().getServer();
        EliminadosData.get(server).remove(p.getUUID());
        p.setGameMode(modo);
        p.setHealth(p.getMaxHealth());
        p.getFoodData().setFoodLevel(20);
        Anuncios.chat(server, Component.literal("\u2728 " + p.getGameProfile().getName() + " volvio al Dedsafio").withStyle(ChatFormatting.GREEN));
        return 1;
    }

    private static int eliminar(CommandContext<CommandSourceStack> c) throws com.mojang.brigadier.exceptions.CommandSyntaxException {
        ServerPlayer p = EntityArgument.getPlayer(c, "jugador");
        EliminadosData.get(c.getSource().getServer()).add(p.getUUID());
        p.setGameMode(GameType.SPECTATOR);
        Anuncios.chat(c.getSource().getServer(), Component.literal("\u2620 " + p.getGameProfile().getName() + " fue eliminado del Dedsafio").withStyle(ChatFormatting.RED));
        return 1;
    }

    private static int listar(CommandContext<CommandSourceStack> c) {
        MinecraftServer server = c.getSource().getServer();
        Set<UUID> todos = EliminadosData.get(server).all();
        GameProfileCache cache = server.getProfileCache();
        StringBuilder sb = new StringBuilder();
        for (UUID u : todos) {
            String nombre = cache == null ? u.toString() : cache.get(u).map(GameProfile::getName).orElse(u.toString());
            if (sb.length() > 0) sb.append(", ");
            sb.append(nombre);
        }
        String texto = todos.isEmpty() ? "No hay eliminados." : "Eliminados (" + todos.size() + "): " + sb;
        c.getSource().sendSuccess(() -> Component.literal(texto), false);
        return todos.size();
    }

    private static int dificultad(CommandContext<CommandSourceStack> c) {
        Difficulty dif = switch (StringArgumentType.getString(c, "nivel").toLowerCase()) {
            case "pacifico" -> Difficulty.PEACEFUL;
            case "facil" -> Difficulty.EASY;
            case "normal" -> Difficulty.NORMAL;
            case "dificil" -> Difficulty.HARD;
            default -> null;
        };
        if (dif == null) { c.getSource().sendFailure(Component.literal("Usa: pacifico, facil, normal o dificil")); return 0; }
        MinecraftServer server = c.getSource().getServer();
        server.setDifficulty(dif, true);
        Anuncios.titulo(server, Component.literal("CAMBIO DE DIFICULTAD").withStyle(ChatFormatting.RED),
                Component.literal("Ahora: " + dif.getDisplayName().getString()));
        return 1;
    }

    private static int ruleta(CommandContext<CommandSourceStack> c) {
        MinecraftServer server = c.getSource().getServer();
        List<? extends String> ops = Config.RULETA.get();
        if (ops.isEmpty()) { c.getSource().sendFailure(Component.literal("La ruleta no tiene opciones en la config")); return 0; }
        String elegida = ops.get(server.overworld().random.nextInt(ops.size()));
        String[] partes = elegida.split("=>", 2);
        String texto = partes[0].trim();
        Anuncios.titulo(server, Component.literal("LA RULETA GIRO").withStyle(ChatFormatting.GOLD),
                Component.literal(texto).withStyle(ChatFormatting.YELLOW));
        if (partes.length == 2) {
            String cmd = partes[1].trim();
            if (cmd.startsWith("/")) cmd = cmd.substring(1);
            server.getCommands().performPrefixedCommand(server.createCommandSourceStack().withSuppressedOutput(), cmd);
        }
        return 1;
    }
}
