# Server estilo Dedsafio (Forge 1.20.1)

Dos partes:
1. `mod/` — **Dedsafio Server Core**, el mod propio (código fuente).
2. Esta guía — qué mods de los que subiste van en el server y cuáles no.

## 1. Conseguir el .jar del mod
Desde donde lo armé **no puedo compilar** (no hay Minecraft/Forge ni internet), así que el .jar lo genera Gradle en tu lado. Dos formas:

**A) Sin instalar nada (GitHub):**
1. Creá un repositorio nuevo en GitHub y subí **el contenido de esta carpeta** (incluida `.github`).
2. Andá a la pestaña **Actions**, abrí "build-jar" y esperá a que termine (unos minutos).
3. Bajá el artefacto `dedsafio_server-jar`: adentro está `dedsafio_server-0.1.0.jar`.

**B) En tu PC:** instalá Java 17 y Gradle 8.8, entrá a `mod/` y corré `gradle build`. El .jar queda en `mod/build/libs/`.

El código **no está probado**: si el build tira errores, pegámelos y lo corrijo.

### Qué trae
| Qué | Detalle |
|---|---|
| Eliminación al morir | Al morir quedás en espectador y se guarda en el mundo (aunque te desconectes). Se apaga con `eliminacion_al_morir=false` en la config. |
| `/dedsafio revive <jugador> [modo]` | Te devuelve al juego (survival por defecto), con vida y comida llenas. |
| `/dedsafio eliminar <jugador>` · `/dedsafio eliminados` | Eliminar a mano / ver la lista. |
| `/dedsafio dificultad pacifico\|facil\|normal\|dificil` | Cambia la dificultad con título en pantalla para todos. |
| `/dedsafio ruleta` | Elige una opción al azar de la config y la anuncia. Cada opción puede llevar un comando: `Texto => comando`. |
| `/dedsafio anuncio <texto>` | Título en pantalla para todos. |
| Deditas (azul, roja, verde) | Items de moneda, con pestaña creativa "Dedsafio". |
| Palito mágico | Click derecho sobre un jugador: lo manda a su respawn (cooldown 10 s). |

Los comandos piden ser operador (nivel 2). Las texturas son placeholders.
La ruleta es de texto, **no visual**. Cajeros, correo, misiones y eventos temporizados quedan para una segunda versión.

## 2. Mods que subiste

**Van (Forge 1.20.1):**
Ad Astra, Botarium, ResourcefulConfig, ResourcefulLib, TerraBlender, AeroBlender, Aether, Ancient Aether, Structure Gel, Blue Skies, Twilight Forest, TF DNV, Curios, Tridot, Valoria, Beyond the Abyss, TATOS (The Abyss), GeckoLib, Cosmic Horizons, The Bumblezone, Sweet Calamity, Macabre, Deeper and Darker.

**No van:**
- `foolish-1_2_2.jar` es de **Minecraft 1.21.1 con NeoForge**. No carga en 1.20.1.
- No pongas juntos `DEDSAFIO4-1_0_0-Forge.jar` y el `dedsafio4-forge-1_1_5` anterior (DEDSAFIO 4 Mechanics): son dos mods distintos del mismo tema y van a duplicar cosas. Elegí uno.

**Faltan:**
- ResourcefulLib (Ad Astra lo exige): ya lo subiste, listo.
- Opcionales: JEI (TATOS) y ParticlePresets (Cosmic Horizons). Funcionan sin ellos.

**Dimensiones que aporta cada uno** (según los archivos de cada jar): Cosmic Horizons 17, Ad Astra 11, Beyond the Abyss 7, TATOS 4, Blue Skies 2, Aether 1, Twilight Forest 1, Valoria 1, Macabre 2, Bumblezone 1, Sweet Calamity 1, Deeper and Darker 1.
Son muchas para un server: más RAM, más tiempo de generación y portales que se pisan en temática (planetas de Ad Astra vs. Cosmic Horizons, dos "Abyss"). Para empezar probá con Twilight Forest + Aether + Deeper and Darker + el Core y sumá de a uno.

## 3. Reglas del server
- Todos los mods van en `mods/` del server **y** de cada jugador (traen items y dimensiones).
- Arrancá con 6–8 GB de RAM (`-Xms6G -Xmx6G`) y probá en un mundo nuevo antes de abrirlo.
- Mundo ya generado + mods de biomas (TerraBlender/AeroBlender): los chunks viejos no cambian.
- **No redistribuyas los jars**: Blue Skies, Cosmic Horizons, TF DNV y los de Dedsafio son "All Rights Reserved", y Valoria y los assets del Aether tienen licencias restrictivas. Compartí la lista de mods, no los archivos.
