package com.chorpan.totemberserker;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.event.entity.living.LivingUseTotemEvent;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

public class BerserkerEvents {
    private static final long DURATION_TICKS = 100L; // 5 segundos
    private static final float DAMAGE_TAKEN_MULTIPLIER = 2.5F;

    @SubscribeEvent
    public void onTotemUsed(LivingUseTotemEvent event) {
        // Solo un jugador que realmente activa un tótem puede iniciar el efecto global.
        if (!(event.getEntity() instanceof ServerPlayer player)) {
            return;
        }

        ServerLevel overworld = player.getServer().overworld();
        BerserkerSavedData data = BerserkerSavedData.get(player.serverLevel());

        // Modo global: cualquier tótem consumido por cualquier jugador reinicia los 5 segundos para TODO el servidor.
        if (data.isEnabled()) {
            data.startGlobalDamageBoost(overworld.getGameTime(), DURATION_TICKS);
        }

        // Modo individual: solo el jugador que consumió el tótem recibe x2,5 durante 5 segundos.
        if (data.isIndividualEnabled()) {
            data.startIndividualDamageBoost(player.getUUID(), overworld.getGameTime(), DURATION_TICKS);
        }
    }

    @SubscribeEvent
    public void onLivingHurt(LivingHurtEvent event) {
        // El multiplicador afecta a jugadores que RECIBEN daño, no a quien lo inflige.
        // Al no filtrar DamageSource, incluye golpes, proyectiles, mobs, lava, fuego,
        // caídas, explosiones y cualquier otra fuente de daño procesada por LivingHurtEvent.
        if (!(event.getEntity() instanceof ServerPlayer victim)) {
            return;
        }

        BerserkerSavedData data = BerserkerSavedData.get(victim.serverLevel());
        long overworldGameTime = victim.getServer().overworld().getGameTime();
        // Si ambos modos están activos, el multiplicador se aplica UNA sola vez (no se acumulan).
        boolean globalActive = data.isGlobalDamageBoostActive(overworldGameTime);
        boolean individualActive = data.isIndividualDamageBoostActive(victim.getUUID(), overworldGameTime);
        if (!globalActive && !individualActive) {
            return;
        }

        event.setAmount(event.getAmount() * DAMAGE_TAKEN_MULTIPLIER);
    }
}
