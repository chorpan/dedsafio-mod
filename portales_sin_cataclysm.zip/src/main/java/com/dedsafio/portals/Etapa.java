package com.dedsafio.portals;

import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.Level;

/** Etapas de la progresion, en orden. */
public enum Etapa {
    OVERWORLD("Overworld"),
    BLUE_SKIES("Blue Skies (Everbright)"),
    EVERDAWN("Blue Skies (Everdawn)"),
    UNDERGARDEN("The Undergarden"),
    OTHERSIDE("Otherside");

    public final String nombre;

    Etapa(String nombre) { this.nombre = nombre; }

    /** Etapas que viven en una dimension propia. */
    public boolean gestionada() { return this == BLUE_SKIES || this == EVERDAWN || this == UNDERGARDEN || this == OTHERSIDE; }

    public static ResourceKey<Level> dimension(Etapa e) {
        return switch (e) {
            case BLUE_SKIES -> clave("blue_skies:everbright");
            case EVERDAWN -> clave("blue_skies:everdawn");
            case UNDERGARDEN -> clave("undergarden:undergarden");
            case OTHERSIDE -> clave("deeperdarker:otherside");
            default -> Level.OVERWORLD;
        };
    }

    private static ResourceKey<Level> clave(String id) {
        return ResourceKey.create(Registries.DIMENSION, new ResourceLocation(id));
    }

    /** Etapa de una dimension (el Overworld siempre da OVERWORLD). null si no pertenece a ninguna. */
    public static Etapa deDimension(ResourceKey<Level> dim) {
        if (dim.equals(Level.OVERWORLD)) return OVERWORLD;
        return switch (dim.location().toString()) {
            case "blue_skies:everbright" -> BLUE_SKIES;
            case "blue_skies:everdawn" -> EVERDAWN;
            case "undergarden:undergarden" -> UNDERGARDEN;
            case "deeperdarker:otherside" -> OTHERSIDE;
            default -> null;
        };
    }

    /** Etapa correspondiente a una dimension. El Overworld no tiene una zona final especial. */
    public static Etapa de(Level lvl, BlockPos pos) {
        return deDimension(lvl.dimension());
    }
}
