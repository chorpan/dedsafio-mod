package com.dedsafio.portals;

import java.util.ArrayList;
import java.util.List;
import net.minecraftforge.common.ForgeConfigSpec;

public class Config {
    public static final ForgeConfigSpec SPEC;
    public static final ForgeConfigSpec.BooleanValue ADMIN_LIBRE;
    /** Indice 0 = portal 1 ... indice 4 = portal 5. Entidades que cada jugador debe haber matado para ir ADELANTE. */
    public static final List<ForgeConfigSpec.ConfigValue<List<? extends String>>> REQUISITOS = new ArrayList<>();

    static {
        ForgeConfigSpec.Builder b = new ForgeConfigSpec.Builder();
        ADMIN_LIBRE = b.comment("Si es true, los operadores nivel 4 pueden saltarse las reglas de viaje (solo para pruebas)")
                .define("admin_viaja_libre", false);
        b.comment("Requisitos para ir ADELANTE: entidades que el jugador debe haber matado. IDs que no existan se ignoran.");
        REQUISITOS.add(b.defineListAllowEmpty("requisitos_portal_1", List.<String>of(), o -> o instanceof String));
        REQUISITOS.add(b.defineListAllowEmpty("requisitos_portal_2",
                List.of("blue_skies:alchemist", "blue_skies:arachnarch", "blue_skies:summoner", "blue_skies:starlit_crusher"), o -> o instanceof String));
        REQUISITOS.add(b.defineListAllowEmpty("requisitos_portal_3", List.<String>of(), o -> o instanceof String));
        REQUISITOS.add(b.defineListAllowEmpty("requisitos_portal_4",
                List.of("deeperdarker:stalker", "minecraft:warden"), o -> o instanceof String));
        // Portal 5 = Everbright -> Everdawn (indice 4). Vacio por defecto; agregar IDs de jefes de Everbright si se quiere exigirlos.
        REQUISITOS.add(b.defineListAllowEmpty("requisitos_portal_5", List.<String>of(), o -> o instanceof String));
        SPEC = b.build();
    }
}
