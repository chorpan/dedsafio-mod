package com.dedsafio.templo;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.level.saveddata.SavedData;

/** Estado de cada templo (un jefe por templo), guardado en el mundo. */
public class TemploData extends SavedData {
    public static final class Entrada {
        public String dim = "";
        public boolean muerto;
        public UUID uuid;
        public BlockPos spawn = BlockPos.ZERO;
        public BlockPos ultima;
    }

    private final Map<String, Entrada> mapa = new LinkedHashMap<>();

    public static TemploData get(MinecraftServer server) {
        return server.overworld().getDataStorage().computeIfAbsent(TemploData::load, TemploData::new, "dedsafio_templo_jefe");
    }

    public static TemploData load(CompoundTag tag) {
        TemploData d = new TemploData();
        ListTag lista = tag.getList("templos", Tag.TAG_COMPOUND);
        for (int i = 0; i < lista.size(); i++) {
            CompoundTag t = lista.getCompound(i);
            Entrada e = new Entrada();
            e.dim = t.getString("dim");
            e.muerto = t.getBoolean("muerto");
            if (t.hasUUID("uuid")) e.uuid = t.getUUID("uuid");
            e.spawn = new BlockPos(t.getInt("sx"), t.getInt("sy"), t.getInt("sz"));
            if (t.contains("ux")) e.ultima = new BlockPos(t.getInt("ux"), t.getInt("uy"), t.getInt("uz"));
            d.mapa.put(t.getString("clave"), e);
        }
        return d;
    }

    @Override
    public CompoundTag save(CompoundTag tag) {
        ListTag lista = new ListTag();
        for (Map.Entry<String, Entrada> en : mapa.entrySet()) {
            Entrada e = en.getValue();
            CompoundTag t = new CompoundTag();
            t.putString("clave", en.getKey());
            t.putString("dim", e.dim);
            t.putBoolean("muerto", e.muerto);
            if (e.uuid != null) t.putUUID("uuid", e.uuid);
            t.putInt("sx", e.spawn.getX());
            t.putInt("sy", e.spawn.getY());
            t.putInt("sz", e.spawn.getZ());
            if (e.ultima != null) {
                t.putInt("ux", e.ultima.getX());
                t.putInt("uy", e.ultima.getY());
                t.putInt("uz", e.ultima.getZ());
            }
            lista.add(t);
        }
        tag.put("templos", lista);
        return tag;
    }

    public Entrada get(String clave) { return mapa.get(clave); }

    public Entrada crear(String clave, String dim, BlockPos spawn) {
        Entrada e = new Entrada();
        e.dim = dim;
        e.spawn = spawn;
        e.ultima = spawn;
        mapa.put(clave, e);
        setDirty();
        return e;
    }

    public void quitar(String clave) {
        mapa.remove(clave);
        setDirty();
    }

    /** Copia para poder iterar mientras se agregan/quitan templos. */
    public List<Map.Entry<String, Entrada>> todas() {
        return new ArrayList<>(mapa.entrySet());
    }
}
