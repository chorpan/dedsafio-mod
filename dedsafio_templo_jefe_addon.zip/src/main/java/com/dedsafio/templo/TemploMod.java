package com.dedsafio.templo;

import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.config.ModConfig;

@Mod(TemploMod.MODID)
public class TemploMod {
    public static final String MODID = "dedsafio_templo_jefe";

    public TemploMod() {
        ModLoadingContext.get().registerConfig(ModConfig.Type.SERVER, Config.SPEC);
    }
}
