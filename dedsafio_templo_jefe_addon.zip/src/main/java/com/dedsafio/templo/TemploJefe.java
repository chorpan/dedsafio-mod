package com.dedsafio.templo;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ThreadLocalRandom;

import com.mojang.brigadier.context.CommandContext;

import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.Registries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerBossEvent;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.Unit;
import net.minecraft.world.BossEvent;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.Pose;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.memory.MemoryModuleType;
import net.minecraft.world.entity.monster.warden.Warden;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraft.world.item.enchantment.Enchantments;
import net.minecraft.world.level.levelgen.structure.BoundingBox;
import net.minecraft.world.level.levelgen.structure.PoolElementStructurePiece;
import net.minecraft.world.level.levelgen.structure.Structure;
import net.minecraft.world.level.levelgen.structure.StructurePiece;
import net.minecraft.world.level.levelgen.structure.StructureStart;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.EntityJoinLevelEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.server.ServerStoppedEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.server.ServerLifecycleHooks;

/**
 * El Guardian del Umbral (Warden gigante del mod Dedsafio Portales) viviendo en cada
 * Ancient Temple de Deeper and Darker. Un jefe por templo.
 */
@Mod.EventBusSubscriber(modid = TemploMod.MODID)
public final class TemploJefe {
    /** Mismo nombre que el jefe original: el render del cliente lo reconoce por el nombre. */
    public static final String NOMBRE = "El Guardián del Umbral";
    private static final String TAG_JEFE = "DedsafioTemploJefe";
    private static final String TAG_CLAVE = "DedsafioTemploClave";
    /** Revisiones (cada 10 ticks) sin encontrar al jefe antes de hacerlo reaparecer = 30 segundos. */
    private static final int REVISIONES_AUSENTE = 60;

    private static final Map<String, ServerBossEvent> BARRAS = new HashMap<>();
    private static final Map<String, Integer> AUSENTE = new HashMap<>();

    private TemploJefe() {}

    // ------------------------------------------------------------------ tick

    @SubscribeEvent
    public static void tick(TickEvent.ServerTickEvent event) {
        if (event.phase != TickEvent.Phase.END || !Config.ACTIVO.get()) return;
        MinecraftServer server = ServerLifecycleHooks.getCurrentServer();
        if (server == null || server.getTickCount() % 10 != 0 || server.overworld() == null) return;
        TemploData data = TemploData.get(server);
        for (String dimStr : Config.DIMENSIONES.get()) {
            ResourceLocation rl = ResourceLocation.tryParse(dimStr);
            if (rl == null) continue;
            ServerLevel lvl = server.getLevel(ResourceKey.create(Registries.DIMENSION, rl));
            if (lvl == null) continue;
            procesarNivel(lvl, data);
        }
    }

    private static Structure estructura(ServerLevel lvl) {
        ResourceLocation rl = ResourceLocation.tryParse(Config.ESTRUCTURA.get());
        if (rl == null) return null;
        return lvl.registryAccess().registryOrThrow(Registries.STRUCTURE).get(rl);
    }

    private static String clave(ServerLevel lvl, StructureStart start) {
        return lvl.dimension().location() + "|" + start.getChunkPos().x + "|" + start.getChunkPos().z;
    }

    private static void procesarNivel(ServerLevel lvl, TemploData data) {
        Structure estructura = estructura(lvl);
        if (estructura == null) return;

        // 1) Un jugador entro a un templo que todavia no tiene jefe: aparece.
        for (ServerPlayer p : lvl.players()) {
            if (p.isSpectator()) continue;
            StructureStart start = lvl.structureManager().getStructureAt(p.blockPosition(), estructura);
            if (!start.isValid()) continue;
            String clave = clave(lvl, start);
            if (data.get(clave) != null) continue;
            BlockPos punto = elegirPunto(lvl, start);
            if (punto == null) continue; // chunks sin cargar: se reintenta en la proxima revision
            TemploData.Entrada en = data.crear(clave, lvl.dimension().location().toString(), punto);
            if (!invocar(lvl, clave, en, punto)) data.quitar(clave);
        }

        // 2) Mantener a los jefes ya existentes de esta dimension.
        String dimId = lvl.dimension().location().toString();
        for (Map.Entry<String, TemploData.Entrada> ent : data.todas()) {
            TemploData.Entrada en = ent.getValue();
            if (en.muerto || !dimId.equals(en.dim)) continue;
            mantener(lvl, data, ent.getKey(), en);
        }
    }

    // ------------------------------------------------------------ aparicion

    private static boolean invocar(ServerLevel lvl, String clave, TemploData.Entrada en, BlockPos pos) {
        Warden boss = EntityType.WARDEN.create(lvl);
        if (boss == null) return false;
        configurar(boss, clave, pos);
        en.uuid = boss.getUUID();
        en.ultima = pos;
        // TRIGGERED = el Warden sale de la tierra con su animacion y sonido de "emerger".
        boss.finalizeSpawn(lvl, lvl.getCurrentDifficultyAt(pos), MobSpawnType.TRIGGERED, null, null);
        lvl.addFreshEntity(boss);
        TemploData.get(lvl.getServer()).setDirty();
        double r2 = (double) Config.RADIO_BARRA.get() * Config.RADIO_BARRA.get();
        for (ServerPlayer p : lvl.players()) {
            if (p.distanceToSqr(pos.getX() + 0.5, pos.getY(), pos.getZ() + 0.5) <= r2) {
                p.displayClientMessage(Component.literal("Algo antiguo despierta en lo profundo del templo..."), true);
            }
        }
        return true;
    }

    /** Mismas caracteristicas que "El Guardian del Umbral" del mod Dedsafio Portales. */
    private static void configurar(Warden boss, String clave, BlockPos pos) {
        boss.moveTo(pos.getX() + 0.5, pos.getY(), pos.getZ() + 0.5, 0.0F, 0.0F);
        CompoundTag pd = boss.getPersistentData();
        pd.putBoolean(TAG_JEFE, true);
        pd.putString(TAG_CLAVE, clave);
        boss.setCustomName(Component.literal(NOMBRE));
        boss.setCustomNameVisible(true);
        boss.setPersistenceRequired();
        ajustar(boss, Attributes.MAX_HEALTH, Config.VIDA.get());
        // Se mantiene el dano de combate del Warden: solo vida, defensa y velocidad.
        ajustar(boss, Attributes.MOVEMENT_SPEED, 0.45D);
        ajustar(boss, Attributes.ARMOR, 20.0D);
        ajustar(boss, Attributes.ARMOR_TOUGHNESS, 10.0D);
        ajustar(boss, Attributes.KNOCKBACK_RESISTANCE, 1.0D);
        boss.setHealth(boss.getMaxHealth());
        boss.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, Integer.MAX_VALUE, 1, false, false));
    }

    private static void ajustar(LivingEntity e, Attribute a, double valor) {
        AttributeInstance inst = e.getAttribute(a);
        if (inst != null) inst.setBaseValue(valor);
    }

    /**
     * Donde aparece: sala del trono si el templo la tiene; si no, la sala central del sotano;
     * si no, la pieza del sotano mas cercana al centro del templo.
     */
    private static BlockPos elegirPunto(ServerLevel lvl, StructureStart start) {
        BlockPos centro = start.getBoundingBox().getCenter();
        record Cand(StructurePiece pieza, int prio, double dist) {}
        List<Cand> cands = new ArrayList<>();
        for (StructurePiece pieza : start.getPieces()) {
            String desc = pieza instanceof PoolElementStructurePiece pe ? pe.getElement().toString() : "";
            int prio;
            if (desc.contains("rooms/throne")) prio = 0;
            else if (desc.contains("basement/center")) prio = 1;
            else if (desc.contains("/basement/")) prio = 2;
            else prio = 3;
            BlockPos c = pieza.getBoundingBox().getCenter();
            double dx = c.getX() - centro.getX();
            double dz = c.getZ() - centro.getZ();
            cands.add(new Cand(pieza, prio, dx * dx + dz * dz));
        }
        cands.sort(Comparator.<Cand>comparingInt(Cand::prio).thenComparingDouble(Cand::dist));
        for (Cand c : cands) {
            BoundingBox bb = c.pieza().getBoundingBox();
            BlockPos cb = bb.getCenter();
            if (!lvl.hasChunkAt(cb)) continue;
            BlockPos hueco = buscarHueco(lvl, bb);
            if (hueco != null) return hueco;
        }
        // Ultimo recurso: piso de la mejor pieza cuyo chunk este cargado.
        for (Cand c : cands) {
            BoundingBox bb = c.pieza().getBoundingBox();
            BlockPos cb = bb.getCenter();
            if (lvl.hasChunkAt(cb)) return new BlockPos(cb.getX(), bb.minY() + 1, cb.getZ());
        }
        return null;
    }

    /** Busca (cerca del centro de la pieza) un lugar con piso y 3 bloques de aire encima. */
    private static BlockPos buscarHueco(ServerLevel lvl, BoundingBox bb) {
        BlockPos c = bb.getCenter();
        for (int r = 0; r <= 3; r++) {
            for (int dx = -r; dx <= r; dx++) {
                for (int dz = -r; dz <= r; dz++) {
                    if (Math.max(Math.abs(dx), Math.abs(dz)) != r) continue;
                    for (int y = bb.minY() + 1; y <= bb.maxY() - 3; y++) {
                        BlockPos p = new BlockPos(c.getX() + dx, y, c.getZ() + dz);
                        if (libre(lvl, p) && libre(lvl, p.above()) && libre(lvl, p.above(2)) && !libre(lvl, p.below())) {
                            return p;
                        }
                    }
                }
            }
        }
        return null;
    }

    private static boolean libre(ServerLevel lvl, BlockPos p) {
        return lvl.getBlockState(p).getCollisionShape(lvl, p).isEmpty();
    }

    // ------------------------------------------------------------ mantenimiento

    private static void mantener(ServerLevel lvl, TemploData data, String clave, TemploData.Entrada en) {
        Entity ent = en.uuid == null ? null : lvl.getEntity(en.uuid);
        if (ent instanceof Warden w && w.isAlive()) {
            AUSENTE.remove(clave);
            en.ultima = w.blockPosition();
            sostener(lvl, w);
            actualizarBarra(clave, lvl, w);
            return;
        }
        // Jefe no cargado (o perdido): sin barra.
        quitarBarra(clave);
        if (!Config.REAPARECER.get()) return;
        BlockPos ref = en.ultima != null ? en.ultima : en.spawn;
        if (!lvl.hasChunkAt(ref) || !hayJugadorCerca(lvl, ref, 48.0D)) {
            AUSENTE.remove(clave);
            return;
        }
        int n = AUSENTE.merge(clave, 1, Integer::sum);
        if (n >= REVISIONES_AUSENTE) {
            AUSENTE.remove(clave);
            invocar(lvl, clave, en, en.spawn);
        }
    }

    private static boolean hayJugadorCerca(ServerLevel lvl, BlockPos pos, double radio) {
        double r2 = radio * radio;
        for (ServerPlayer p : lvl.players()) {
            if (!p.isSpectator() && p.distanceToSqr(pos.getX() + 0.5, pos.getY(), pos.getZ() + 0.5) <= r2) return true;
        }
        return false;
    }

    /** Evita que el Warden se entierre y desaparezca, y lo manda contra el jugador mas cercano (64 bloques). */
    private static void sostener(ServerLevel lvl, Warden w) {
        w.getBrain().setMemoryWithExpiry(MemoryModuleType.DIG_COOLDOWN, Unit.INSTANCE, 1200L);
        if (w.getPose() == Pose.EMERGING) return;
        if (w.getBrain().hasMemoryValue(MemoryModuleType.ATTACK_TARGET)) return;
        ServerPlayer cercano = null;
        double mejor = 64.0D * 64.0D;
        for (ServerPlayer p : lvl.players()) {
            if (p.isSpectator() || p.isCreative() || !p.isAlive()) continue;
            double d = p.distanceToSqr(w);
            if (d < mejor) {
                mejor = d;
                cercano = p;
            }
        }
        if (cercano != null) w.increaseAngerAt(cercano, 150, false);
    }

    // ------------------------------------------------------------ barra de vida

    private static void actualizarBarra(String clave, ServerLevel lvl, Warden w) {
        ServerBossEvent bar = BARRAS.get(clave);
        if (bar == null) {
            bar = new ServerBossEvent(Component.literal(NOMBRE), BossEvent.BossBarColor.PURPLE, BossEvent.BossBarOverlay.PROGRESS);
            bar.setPlayBossMusic(true);
            BARRAS.put(clave, bar);
        }
        bar.setProgress(Math.max(0.0F, Math.min(1.0F, w.getHealth() / w.getMaxHealth())));
        double r2 = (double) Config.RADIO_BARRA.get() * Config.RADIO_BARRA.get();
        Set<ServerPlayer> deben = new HashSet<>();
        for (ServerPlayer p : lvl.players()) {
            if (p.distanceToSqr(w) <= r2) deben.add(p);
        }
        for (ServerPlayer p : new ArrayList<>(bar.getPlayers())) {
            if (!deben.contains(p)) bar.removePlayer(p);
        }
        for (ServerPlayer p : deben) bar.addPlayer(p);
    }

    private static void quitarBarra(String clave) {
        ServerBossEvent bar = BARRAS.remove(clave);
        if (bar != null) {
            bar.setProgress(0.0F);
            bar.removeAllPlayers();
            bar.setVisible(false);
        }
    }

    @SubscribeEvent
    public static void alCerrar(ServerStoppedEvent event) {
        BARRAS.clear();
        AUSENTE.clear();
    }

    // ------------------------------------------------------------ muerte y recompensa

    @SubscribeEvent
    public static void alMorir(LivingDeathEvent event) {
        LivingEntity v = event.getEntity();
        if (v.level().isClientSide) return;
        CompoundTag pd = v.getPersistentData();
        if (!pd.getBoolean(TAG_JEFE)) return;
        MinecraftServer server = v.getServer();
        if (server == null || server.overworld() == null || !(v.level() instanceof ServerLevel lvl)) return;
        String clave = pd.getString(TAG_CLAVE);
        TemploData data = TemploData.get(server);
        TemploData.Entrada en = data.get(clave);
        if (en == null || en.muerto) return;
        en.muerto = true;
        en.uuid = null;
        data.setDirty();
        quitarBarra(clave);
        AUSENTE.remove(clave);
        recompensar(lvl, v.blockPosition());
    }

    /** Evita duplicados: si un jefe viejo vuelve a cargarse y ya hay otro (o el templo se reinicio / murio), se descarta. */
    @SubscribeEvent
    public static void alUnirse(EntityJoinLevelEvent event) {
        if (event.getLevel().isClientSide()) return;
        Entity ent = event.getEntity();
        if (!(ent instanceof Warden)) return;
        CompoundTag pd = ent.getPersistentData();
        if (!pd.getBoolean(TAG_JEFE)) return;
        MinecraftServer server = ent.getServer();
        if (server == null || server.overworld() == null) return;
        TemploData.Entrada en = TemploData.get(server).get(pd.getString(TAG_CLAVE));
        if (en == null || en.muerto || (en.uuid != null && !en.uuid.equals(ent.getUUID()))) {
            event.setCanceled(true);
        }
    }

    private static void recompensar(ServerLevel lvl, BlockPos centro) {
        double r2 = (double) Config.RADIO_RECOMPENSA.get() * Config.RADIO_RECOMPENSA.get();
        for (ServerPlayer p : lvl.players()) {
            if (p.isSpectator() || p.distanceToSqr(centro.getX() + 0.5, centro.getY(), centro.getZ() + 0.5) > r2) continue;
            List<ItemStack> botin = generarBotin();
            if (Config.MOCHILA.get()) {
                entregar(p, crearMochila(botin));
                p.displayClientMessage(Component.literal("Derrotaron al Guardián del Umbral. Recibiste una Mochila del Desafío."), false);
            } else {
                for (ItemStack s : botin) entregar(p, s);
                p.displayClientMessage(Component.literal("Derrotaron al Guardián del Umbral. Recibiste el botín del Desafío."), false);
            }
        }
    }

    private static void entregar(ServerPlayer p, ItemStack s) {
        if (s.isEmpty()) return;
        if (!p.getInventory().add(s) && !s.isEmpty()) p.drop(s, false);
    }

    private static ItemStack crearMochila(List<ItemStack> botin) {
        ItemStack bundle = new ItemStack(Items.BUNDLE);
        bundle.setHoverName(Component.literal("Mochila del Desafío Final"));
        ListTag items = new ListTag();
        for (ItemStack s : botin) items.add(s.save(new CompoundTag()));
        bundle.getOrCreateTag().put("Items", items);
        return bundle;
    }

    private static List<ItemStack> generarBotin() {
        List<ItemStack> lista = new ArrayList<>();
        int cantidad = 3 + ThreadLocalRandom.current().nextInt(4); // 3 a 6, como el jefe original
        for (int i = 0; i < cantidad; i++) {
            ItemStack s = lootFinal();
            if (!s.isEmpty()) lista.add(s);
        }
        return lista;
    }

    /** Misma tabla de botin que el jefe final del mod Dedsafio Portales. */
    private static ItemStack lootFinal() {
        int roll = ThreadLocalRandom.current().nextInt(100);
        String id;
        int count = 1;
        if (roll < 8) {
            id = switch (ThreadLocalRandom.current().nextInt(4)) {
                case 0 -> "deeperdarker:warden_helmet";
                case 1 -> "deeperdarker:warden_chestplate";
                case 2 -> "deeperdarker:warden_leggings";
                default -> "deeperdarker:warden_boots";
            };
        } else if (roll < 18) {
            id = switch (ThreadLocalRandom.current().nextInt(3)) {
                case 0 -> "deeperdarker:warden_sword";
                case 1 -> "deeperdarker:warden_pickaxe";
                default -> "deeperdarker:warden_axe";
            };
        } else if (roll < 25) {
            id = ThreadLocalRandom.current().nextBoolean() ? "deeperdarker:heart_of_the_deep" : "deeperdarker:reinforced_echo_shard";
        } else if (roll < 38) {
            id = "deeperdarker:warden_upgrade_smithing_template";
        } else {
            id = switch (ThreadLocalRandom.current().nextInt(9)) {
                case 0 -> "deeperdarker:soul_dust";
                case 1 -> "deeperdarker:soul_crystal";
                case 2 -> "deeperdarker:sculk_bone";
                case 3 -> "deeperdarker:grime_ball";
                case 4 -> "minecraft:bone";
                case 5 -> "minecraft:coal";
                case 6 -> "minecraft:rotten_flesh";
                case 7 -> "minecraft:echo_shard";
                default -> "minecraft:sculk";
            };
            count = 1 + ThreadLocalRandom.current().nextInt(5);
        }
        ItemStack stack = item(id, count);
        if (!stack.isEmpty() && roll < 8) {
            EnchantmentHelper.setEnchantments(Map.of(
                    Enchantments.ALL_DAMAGE_PROTECTION, 4,
                    Enchantments.UNBREAKING, 3,
                    Enchantments.MENDING, 1), stack);
        } else if (!stack.isEmpty() && roll >= 8 && roll < 18) {
            EnchantmentHelper.setEnchantments(Map.of(
                    Enchantments.SHARPNESS, 5,
                    Enchantments.UNBREAKING, 3,
                    Enchantments.MENDING, 1), stack);
        }
        return stack;
    }

    private static ItemStack item(String id, int count) {
        ResourceLocation rl = ResourceLocation.tryParse(id);
        if (rl == null) return ItemStack.EMPTY;
        Item item = ForgeRegistries.ITEMS.getValue(rl);
        if (item == null || item == Items.AIR) return ItemStack.EMPTY;
        return new ItemStack(item, count);
    }

    // ------------------------------------------------------------ comando de administracion

    @SubscribeEvent
    public static void comandos(RegisterCommandsEvent event) {
        event.getDispatcher().register(Commands.literal("templo_jefe")
                .requires(s -> s.hasPermission(2))
                .then(Commands.literal("reiniciar").executes(TemploJefe::reiniciar)));
    }

    /** Borra el jefe (y su registro) del templo donde esta parado el admin: al volver a entrar aparece uno nuevo. */
    private static int reiniciar(CommandContext<CommandSourceStack> ctx) {
        CommandSourceStack src = ctx.getSource();
        ServerLevel lvl = src.getLevel();
        Structure estructura = estructura(lvl);
        if (estructura == null) {
            src.sendFailure(Component.literal("La estructura configurada no existe en esta dimension."));
            return 0;
        }
        StructureStart start = lvl.structureManager().getStructureAt(BlockPos.containing(src.getPosition()), estructura);
        if (!start.isValid()) {
            src.sendFailure(Component.literal("No estas dentro de un templo."));
            return 0;
        }
        String clave = clave(lvl, start);
        TemploData data = TemploData.get(lvl.getServer());
        TemploData.Entrada en = data.get(clave);
        if (en == null) {
            src.sendFailure(Component.literal("Este templo todavia no tiene jefe registrado."));
            return 0;
        }
        if (en.uuid != null) {
            Entity viejo = lvl.getEntity(en.uuid);
            if (viejo != null) viejo.discard();
        }
        data.quitar(clave);
        quitarBarra(clave);
        AUSENTE.remove(clave);
        src.sendSuccess(() -> Component.literal("Jefe del templo reiniciado: aparecera uno nuevo cuando un jugador entre."), true);
        return 1;
    }
}
