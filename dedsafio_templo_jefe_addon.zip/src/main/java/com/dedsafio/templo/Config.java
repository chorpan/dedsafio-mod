package com.dedsafio.templo;

import java.util.List;
import net.minecraftforge.common.ForgeConfigSpec;

/** Config del mundo (carpeta serverconfig). */
public final class Config {
    public static final ForgeConfigSpec SPEC;
    public static final ForgeConfigSpec.BooleanValue ACTIVO;
    public static final ForgeConfigSpec.ConfigValue<String> ESTRUCTURA;
    public static final ForgeConfigSpec.ConfigValue<List<? extends String>> DIMENSIONES;
    public static final ForgeConfigSpec.DoubleValue VIDA;
    public static final ForgeConfigSpec.IntValue RADIO_BARRA;
    public static final ForgeConfigSpec.IntValue RADIO_RECOMPENSA;
    public static final ForgeConfigSpec.BooleanValue REAPARECER;
    public static final ForgeConfigSpec.BooleanValue MOCHILA;

    static {
        ForgeConfigSpec.Builder b = new ForgeConfigSpec.Builder();
        ACTIVO = b.comment("Si es false, no aparecen jefes nuevos en los templos.")
                .define("activo", true);
        ESTRUCTURA = b.comment("Estructura donde aparece el jefe.")
                .define("estructura", "deeperdarker:ancient_temple");
        DIMENSIONES = b.comment("Dimensiones donde se busca la estructura.")
                .defineListAllowEmpty("dimensiones", List.of("deeperdarker:otherside"), o -> o instanceof String);
        VIDA = b.comment("Vida maxima del jefe. Minecraft limita MAX_HEALTH a 1024 (el mod original pedia 1500, que en la practica queda en 1024).")
                .defineInRange("vida_jefe", 1024.0D, 1.0D, 1024.0D);
        RADIO_BARRA = b.comment("Radio (bloques) dentro del cual los jugadores ven la barra de vida y la musica del jefe.")
                .defineInRange("radio_barra", 96, 16, 512);
        RADIO_RECOMPENSA = b.comment("Radio (bloques) alrededor del jefe muerto dentro del cual cada jugador recibe su Mochila.")
                .defineInRange("radio_recompensa", 96, 8, 512);
        REAPARECER = b.comment("Si el jefe desaparece sin morir (chunk perdido, bug), vuelve a aparecer en su punto de origen.")
                .define("reaparecer_si_desaparece", true);
        MOCHILA = b.comment("true = la recompensa viene dentro de una Mochila (bundle). false = los items van sueltos al inventario",
                        "(usar false si el bundle esta desactivado en tu version/mundo).")
                .define("recompensa_en_mochila", true);
        SPEC = b.build();
    }

    private Config() {}
}
