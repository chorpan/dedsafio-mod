package com.dedsafio.templo;

import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.monster.warden.Warden;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderLivingEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * Hace visualmente gigante (x3) al jefe, como en el mod original.
 * Se reconoce por el nombre porque los datos persistentes del servidor no llegan al cliente.
 */
@Mod.EventBusSubscriber(modid = TemploMod.MODID, value = Dist.CLIENT)
public final class ClientBossRender {
    private static final float ESCALA = 3.0F;

    private ClientBossRender() {}

    private static boolean esJefe(LivingEntity e) {
        if (!(e instanceof Warden)) return false;
        Component nombre = e.getCustomName();
        return nombre != null && TemploJefe.NOMBRE.equals(nombre.getString());
    }

    @SubscribeEvent
    public static void antes(RenderLivingEvent.Pre<? extends LivingEntity, ?> event) {
        if (esJefe(event.getEntity())) {
            event.getPoseStack().pushPose();
            event.getPoseStack().scale(ESCALA, ESCALA, ESCALA);
        }
    }

    @SubscribeEvent
    public static void despues(RenderLivingEvent.Post<? extends LivingEntity, ?> event) {
        if (esJefe(event.getEntity())) {
            event.getPoseStack().popPose();
        }
    }
}
