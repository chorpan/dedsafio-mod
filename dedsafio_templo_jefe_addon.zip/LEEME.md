# Dedsafio Jefe del Templo (Forge 1.20.1) — addon

Hace que **El Guardián del Umbral** (el jefe Warden gigante de *Dedsafio Portales*) viva en cada
**Ancient Temple** (`deeperdarker:ancient_temple`) de Deeper and Darker (dimensión Otherside).

## Cómo funciona
- Cuando un jugador entra a un Ancient Temple que todavía no tiene jefe, el Warden sale de la tierra
  (animación de "emerger") en la **sala del trono**; si ese templo no la tiene, en la sala central del sótano;
  si tampoco, en la pieza del sótano más cercana al centro.
- **Un jefe por templo**, guardado en el mundo (`dedsafio_templo_jefe`). Funciona con templos ya generados.
- Si muere no vuelve a aparecer. Si desaparece sin morir (chunk perdido, bug), reaparece a los 30 s con un jugador cerca.
- Se evita que el Warden se entierre (dig) y se lo manda contra el jugador más cercano (64 bloques).

## Características copiadas del jefe original
Nombre "El Guardián del Umbral" visible · vida máxima (tope de Minecraft: 1024) · velocidad base 0.45 + Speed II ·
armadura 20 / dureza 10 · resistencia total al empuje · daño de combate normal del Warden · no despawnea ·
barra de vida **violeta** con música de jefe · tamaño visual x3 (solo cliente; la hitbox es la del Warden) ·
al morir, cada jugador cercano recibe una **Mochila del Desafío Final** con 3-6 items de la misma tabla de botín
(armadura/herramientas Warden, corazón de las profundidades, plantilla de mejora, etc., con sus encantamientos).

## Diferencias a propósito
- El botín va a los jugadores dentro de `radio_recompensa` (96 bloques), no a todos los conectados (hay muchos templos).
- El jefe del templo **no** usa las marcas del jefe final del mod de portales, así que no marca "jefe final derrotado"
  ni le da mochilas a todo el servidor. Pero sigue siendo un `minecraft:warden`: **matarlo cuenta** para el requisito
  del portal 4 (`requisitos_portal_4`).

## Comando (nivel 2)
`/templo_jefe reiniciar` — parado dentro de un templo: borra su jefe y su registro; vuelve a aparecer al entrar de nuevo.

## Config (serverconfig/dedsafio_templo_jefe-server.toml)
`activo`, `estructura`, `dimensiones`, `vida_jefe`, `radio_barra`, `radio_recompensa`,
`reaparecer_si_desaparece`, `recompensa_en_mochila` (false = items sueltos al inventario).

## Compilar
```
gradlew build      ->  build/libs/dedsafio_templo_jefe-1.0.0.jar
```
Java 17, Forge 47.3.0. Va en `mods/` junto a Deeper and Darker 1.3.x (obligatorio) y Dedsafio Portales (opcional).

## Sin probar
Escrito sin poder compilar ni ejecutar (sin Minecraft/Forge en el entorno donde se hizo). Los IDs de items de
Deeper and Darker sí se verificaron contra el jar 1.3.3.
